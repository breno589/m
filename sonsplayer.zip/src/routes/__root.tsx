import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { App } from "@capacitor/app";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { PlayerProvider } from "@/lib/player-store";
import { YouTubeEngine } from "@/components/youtube-engine";
import { PlayerBar } from "@/components/player-bar";
import { AppShell } from "@/components/app-shell";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center gradient-hero px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold gradient-text">404</h1>
        <h2 className="mt-4 text-xl font-semibold">Faixa não encontrada</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Essa página não existe ou foi movida.
        </p>
        <a
          href="/"
          className="mt-6 inline-flex items-center justify-center rounded-full gradient-brand px-5 py-2 text-sm font-medium text-white glow"
        >
          Voltar ao início
        </a>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold">Algo saiu do ritmo</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Não conseguimos carregar essa página.
        </p>
        <button
          onClick={() => {
            router.invalidate();
            reset();
          }}
          className="mt-6 inline-flex items-center justify-center rounded-full gradient-brand px-5 py-2 text-sm font-medium text-white glow"
        >
          Tentar novamente
        </button>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "SonsPlayer — Início" },
      {
        name: "description",
        content:
          "Descubra playlists, lançamentos e músicas em alta no SonsPlayer.",
      },
      { name: "theme-color", content: "#0D0D0D" },
      { property: "og:title", content: "SonsPlayer — Início" },
      {
        property: "og:description",
        content: "Descubra playlists, lançamentos e músicas em alta no SonsPlayer.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "SonsPlayer — Início" },
      { name: "twitter:description", content: "Descubra playlists, lançamentos e músicas em alta no SonsPlayer." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/633d72e0-452d-4eaf-a018-6f005d5fceae/id-preview-33c5f8d3--8a829f4d-2730-4989-90d2-7a23f17977df.lovable.app-1784418942444.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/633d72e0-452d-4eaf-a018-6f005d5fceae/id-preview-33c5f8d3--8a829f4d-2730-4989-90d2-7a23f17977df.lovable.app-1784418942444.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/__l5e/assets-v1/8321b608-5a54-4a1e-8c8a-8502017dbf69/sonsplayer-logo.png", type: "image/png" },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/icons/icon-512.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR" className="dark">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const router = useRouter();

  useEffect(() => {
    // Configura interceptação de Deep Links via Capacitor App Plugin
    const setupAppListeners = async () => {
      App.addListener('appUrlOpen', (data) => {
        try {
          // data.url será algo como https://sonsplayer.lovable.app/playlist/p1
          const url = new URL(data.url);
          const path = url.pathname + url.search + url.hash;
          router.navigate({ to: path });
        } catch (e) {
          console.error("Deep link parse error", e);
        }
      });
    };

    setupAppListeners();

    let cancelled = false;
    import("@/lib/register-sw").then((m) => {
      if (!cancelled) m.registerSonsPlayerSW();
    });
    return () => {
      cancelled = true;
      App.removeAllListeners();
    };
  }, [router]);
  return (
    <QueryClientProvider client={queryClient}>
      <PlayerProvider>
        <AppShell>
          <Outlet />
        </AppShell>
        <PlayerBar />
        <YouTubeEngine />
        <OfflineBanner />
      </PlayerProvider>
    </QueryClientProvider>
  );
}

function OfflineBanner() {
  const [online, setOnline] = useState(true);
  useEffect(() => {
    if (typeof navigator === "undefined") return;
    setOnline(navigator.onLine);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);
  if (online) return null;
  return (
    <div className="fixed top-3 left-1/2 -translate-x-1/2 z-[70] flex items-center gap-3 rounded-full glass px-4 py-2 text-xs shadow-lg border border-white/10">
      <span>Você está offline — apenas músicas baixadas serão reproduzidas sem interrupções.</span>
      <button 
        onClick={() => window.location.reload()} 
        className="ml-2 underline hover:text-primary transition-colors"
      >
        Recarregar
      </button>
    </div>
  );
}
