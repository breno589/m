import { createFileRoute } from "@tanstack/react-router";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PLAYLISTS, TRACKS } from "@/lib/catalog";
import { PlaylistTile } from "@/components/card-tile";
import { TrackRow } from "@/components/track-row";
import { usePlayer } from "@/lib/player-store";
import { Heart, Download, Trash2, HardDrive } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { get, keys } from "idb-keyval";
import type { Track } from "@/lib/catalog";

export const Route = createFileRoute("/library")({
  component: Library,
  head: () => ({
    meta: [
      { title: "Biblioteca — SonsPlayer" },
      { name: "description", content: "Suas músicas favoritas, playlists e histórico." },
    ],
  }),
});

function Library() {
  const p = usePlayer();
  const [offlineOnly, setOfflineOnly] = useState(false);
  
  const favTracks = TRACKS.filter((t) => p.favorites.has(t.id))
    .filter(t => !offlineOnly || p.downloaded.has(t.id));
    
  const [downloadedTracks, setDownloadedTracks] = useState<Track[]>([]);

  useEffect(() => {
    const loadDownloaded = async () => {
      const allKeys = await keys();
      const dlKeys = allKeys.filter((k) => typeof k === "string" && k.startsWith("dl_"));
      const items = await Promise.all(dlKeys.map((k) => get<Track>(k)));
      setDownloadedTracks(items.filter(Boolean) as Track[]);
    };
    loadDownloaded();
  }, [p.downloaded]);

  const formatSize = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  return (
    <div className="px-6 sm:px-10 py-8 max-w-[1600px] mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">Sua biblioteca</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Tudo que você curte em um só lugar.
        </p>
      </div>

      <Tabs defaultValue="favorites" className="w-full">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <TabsList className="glass w-fit">
            <TabsTrigger value="favorites">Favoritas</TabsTrigger>
            <TabsTrigger value="playlists">Playlists</TabsTrigger>
            <TabsTrigger value="artists">Artistas</TabsTrigger>
            <TabsTrigger value="offline">
              <Download className="h-3 w-3 mr-2" />
              Downloads
            </TabsTrigger>
          </TabsList>

          <button
            onClick={() => setOfflineOnly(!offlineOnly)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs border transition w-fit ${
              offlineOnly 
                ? "bg-primary/20 text-primary border-primary/30" 
                : "border-white/10 text-muted-foreground hover:text-foreground hover:bg-white/5"
            }`}
          >
            <div className={`w-2 h-2 rounded-full ${offlineOnly ? "bg-primary animate-pulse" : "bg-muted-foreground"}`} />
            Somente offline
          </button>
        </div>

        <TabsContent value="favorites" className="mt-0">
          {favTracks.length === 0 ? (
            <div className="rounded-2xl glass p-10 text-center">
              <Heart className="h-8 w-8 text-primary mx-auto mb-3" />
              <p className="font-medium">Nenhuma favorita ainda</p>
              <p className="text-sm text-muted-foreground mt-1">
                Toque no coração de qualquer música para adicioná-la aqui.
              </p>
            </div>
          ) : (
            <div className="rounded-2xl bg-card/50 p-2">
              {favTracks.map((t, i) => (
                <TrackRow
                  key={t.id}
                  track={t}
                  index={i}
                  onPlay={() => p.playTracks(favTracks, i)}
                />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="playlists" className="mt-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
            {PLAYLISTS.map((pl) => (
              <PlaylistTile
                key={pl.id}
                id={pl.id}
                title={pl.title}
                description={pl.description}
                cover={pl.cover}
              />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="artists" className="mt-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
            {Array.from(new Set(TRACKS.map((t) => t.artist))).map((a) => {
              const cover = TRACKS.find((t) => t.artist === a)!.cover;
              return (
                <div key={a} className="text-center card-hover">
                  <img
                    src={cover}
                    alt=""
                    className="aspect-square w-full object-cover rounded-full shadow-lg"
                  />
                  <div className="mt-2 text-sm font-medium truncate">{a}</div>
                  <div className="text-xs text-muted-foreground">Artista</div>
                </div>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="offline" className="mt-6 space-y-6">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="flex items-center gap-4 glass rounded-2xl p-6">
              <div className="h-12 w-12 rounded-xl gradient-brand grid place-items-center glow">
                <HardDrive className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Armazenamento</h3>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                  <span>{p.downloaded.size} músicas</span>
                  <span>•</span>
                  <span className="text-primary font-medium">{formatSize(p.storageUsage)}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 glass rounded-2xl p-6">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => p.clearDownloads(undefined)}
                disabled={p.downloaded.size === 0}
                className="rounded-full px-5 border-white/10"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Limpar tudo
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between px-2">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Por Artista / Álbum</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {Array.from(new Set(downloadedTracks.map(t => t.artist))).slice(0, 6).map(artist => (
                <div key={artist} className="glass rounded-xl p-4 flex items-center justify-between group">
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{artist}</p>
                    <p className="text-xs text-muted-foreground">
                      {downloadedTracks.filter(t => t.artist === artist).length} músicas
                    </p>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 text-muted-foreground hover:text-destructive transition-colors opacity-0 group-hover:opacity-100"
                    onClick={() => p.clearDownloads({ artist })}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              {Array.from(new Set(downloadedTracks.filter(t => t.album).map(t => t.album!))).slice(0, 6).map(album => (
                <div key={album} className="glass rounded-xl p-4 flex items-center justify-between group border-l-2 border-primary/30">
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{album}</p>
                    <p className="text-xs text-muted-foreground">Álbum • {downloadedTracks.filter(t => t.album === album).length} músicas</p>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 text-muted-foreground hover:text-destructive transition-colors opacity-0 group-hover:opacity-100"
                    onClick={() => p.clearDownloads({ album })}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between px-2">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Todas as músicas baixadas</h3>
            </div>
            
            {downloadedTracks.length === 0 ? (
              <div className="rounded-2xl glass p-10 text-center">
                <Download className="h-8 w-8 text-primary mx-auto mb-3" />
                <p className="font-medium">Nenhum download ainda</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Baixe músicas para ouvi-las sem conexão com a internet.
                </p>
              </div>
            ) : (
              <div className="rounded-2xl bg-card/50 p-2">
                {downloadedTracks.map((t, i) => (
                  <TrackRow
                    key={t.id}
                    track={t}
                    index={i}
                    onPlay={() => p.playTracks(downloadedTracks, i)}
                  />
                ))}
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}