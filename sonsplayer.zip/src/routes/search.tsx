import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useInfiniteQuery } from "@tanstack/react-query";
import { Search as SearchIcon, Loader2 } from "lucide-react";
import { PLAYLISTS, GENRES, type Track } from "@/lib/catalog";
import { TrackRow } from "@/components/track-row";
import { PlaylistTile } from "@/components/card-tile";
import { usePlayer } from "@/lib/player-store";
import { searchYouTube, type YouTubeSearchPage } from "@/lib/youtube.functions";

export const Route = createFileRoute("/search")({
  component: Search,
  head: () => ({
    meta: [
      { title: "Pesquisar — SonsPlayer" },
      { name: "description", content: "Pesquise músicas, artistas, álbuns e playlists no SonsPlayer." },
    ],
  }),
});

function Search() {
  const p = usePlayer();
  const [q, setQ] = useState("");
  const [debounced, setDebounced] = useState("");
  const [genre, setGenre] = useState<string | null>(null);
  const [offlineOnly, setOfflineOnly] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(q.trim()), 350);
    return () => clearTimeout(t);
  }, [q]);

  const effectiveQ = useMemo(() => {
    if (debounced) return debounced;
    if (genre) return `${genre} music`;
    return "";
  }, [debounced, genre]);

  const {
    data,
    isFetching,
    isFetchingNextPage,
    fetchNextPage,
    hasNextPage,
    error,
  } = useInfiniteQuery<YouTubeSearchPage>({
    queryKey: ["yt-search", effectiveQ],
    queryFn: ({ pageParam }) =>
      searchYouTube({
        data: { q: effectiveQ, limit: 24, pageToken: (pageParam as string) || undefined },
      }),
    initialPageParam: "",
    getNextPageParam: (last) => last.nextPageToken ?? undefined,
    enabled: effectiveQ.length > 0,
    staleTime: 5 * 60 * 1000,
  });

  const results = useMemo<Track[]>(() => {
    const seen = new Set<string>();
    const out: Track[] = [];
    for (const pg of data?.pages ?? []) {
      for (const t of pg.tracks) {
        if (seen.has(t.id)) continue;
        seen.add(t.id);
        out.push(t);
      }
    }
    if (offlineOnly) {
      return out.filter(t => p.downloaded.has(t.id));
    }
    return out;
  }, [data, offlineOnly, p.downloaded]);

  // Sentinela para infinite scroll
  const sentinelRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const el = sentinelRef.current;
    if (!el || !hasNextPage || isFetchingNextPage) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) fetchNextPage();
      },
      { rootMargin: "400px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage, results.length]);


  const playlistResults = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return PLAYLISTS;
    return PLAYLISTS.filter(
      (pl) =>
        pl.title.toLowerCase().includes(s) || pl.description.toLowerCase().includes(s)
    );
  }, [q]);

  return (
    <div className="px-6 sm:px-10 py-8 max-w-[1600px] mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-semibold mb-4">Pesquisar</h1>
        <div className="relative max-w-2xl">
          <SearchIcon className="h-4 w-4 absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="O que você quer ouvir hoje?"
            className="w-full h-12 rounded-full pl-11 pr-11 glass focus:outline-none focus:ring-2 focus:ring-ring text-sm"
          />
          {isFetching && (
            <Loader2 className="h-4 w-4 absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground animate-spin" />
          )}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <div className="flex flex-wrap gap-2 mr-2 border-r border-white/10 pr-4">
          <button
            onClick={() => setGenre(null)}
            className={`px-3 py-1.5 rounded-full text-xs border transition ${
              !genre ? "gradient-brand text-white border-transparent" : "border-white/10 text-muted-foreground hover:text-foreground"
            }`}
          >
            Todos
          </button>
          {GENRES.map((g) => (
            <button
              key={g}
              onClick={() => setGenre(g === genre ? null : g)}
              className={`px-3 py-1.5 rounded-full text-xs border transition ${
                g === genre
                  ? "gradient-brand text-white border-transparent"
                  : "border-white/10 text-muted-foreground hover:text-foreground"
              }`}
            >
              {g}
            </button>
          ))}
        </div>

        <button
          onClick={() => setOfflineOnly(!offlineOnly)}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs border transition ${
            offlineOnly 
              ? "bg-primary/20 text-primary border-primary/30" 
              : "border-white/10 text-muted-foreground hover:text-foreground"
          }`}
        >
          <div className={`w-2 h-2 rounded-full ${offlineOnly ? "bg-primary animate-pulse" : "bg-muted-foreground"}`} />
          Somente offline
        </button>
      </div>

      <section>
        <h2 className="text-lg font-semibold mb-3">
          {effectiveQ ? `Resultados para "${effectiveQ}"` : "Comece a digitar para buscar"}
        </h2>
        {error ? (
          <p className="text-sm text-destructive">
            Erro ao buscar no YouTube: {(error as Error).message}
          </p>
        ) : !effectiveQ ? (
          <p className="text-sm text-muted-foreground">
            Digite o nome de uma música, artista ou álbum — ou escolha um gênero acima.
          </p>
        ) : results.length === 0 && !isFetching ? (
          <p className="text-sm text-muted-foreground">Nenhuma faixa encontrada.</p>
        ) : (
          <>
            <div className="rounded-2xl bg-card/50 p-2">
              {results.map((t, i) => (
                <TrackRow
                  key={t.id}
                  track={t}
                  index={i}
                  onPlay={() => p.playTracks(results, i)}
                />
              ))}
            </div>
            <div ref={sentinelRef} className="h-1" />
            <div className="flex justify-center py-6">
              {isFetchingNextPage ? (
                <span className="inline-flex items-center gap-2 text-xs text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" /> Carregando mais…
                </span>
              ) : hasNextPage ? (
                <button
                  onClick={() => fetchNextPage()}
                  className="px-4 py-2 rounded-full text-xs border border-white/10 hover:bg-white/5 transition"
                >
                  Carregar mais
                </button>
              ) : results.length > 0 ? (
                <span className="text-xs text-muted-foreground">Fim dos resultados</span>
              ) : null}
            </div>
          </>
        )}
      </section>

      <section>
        <h2 className="text-lg font-semibold mb-3">Playlists</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
          {playlistResults.map((pl) => (
            <PlaylistTile
              key={pl.id}
              id={pl.id}
              title={pl.title}
              description={pl.description}
              cover={pl.cover}
            />
          ))}
        </div>
      </section>
    </div>
  );
}
