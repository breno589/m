import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { PLAYLISTS, getPlaylistTracks, type Track } from "@/lib/catalog";
import { TrackRow } from "@/components/track-row";
import { usePlayer } from "@/lib/player-store";
import { Button } from "@/components/ui/button";
import { Play, Shuffle } from "lucide-react";

export const Route = createFileRoute("/playlist/$id")({
  loader: ({ params }) => {
    const pl = PLAYLISTS.find((p) => p.id === params.id);
    if (!pl) throw notFound();
    return { playlist: pl, tracks: getPlaylistTracks(pl.id) };
  },
  component: PlaylistPage,
  notFoundComponent: () => (
    <div className="p-10 text-center">
      <p className="text-muted-foreground">Playlist não encontrada.</p>
      <Link to="/" className="text-primary text-sm">Voltar</Link>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="p-10 text-center text-muted-foreground">{error.message}</div>
  ),
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.playlist.title} — SonsPlayer` },
          { name: "description", content: loaderData.playlist.description },
        ]
      : [{ title: "Playlist — SonsPlayer" }],
  }),
});

function PlaylistPage() {
  const { playlist, tracks } = Route.useLoaderData();
  const p = usePlayer();

  return (
    <div>
      <section className="relative px-6 sm:px-10 pt-10 pb-8 gradient-hero">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row gap-6 items-end">
          <img
            src={playlist.cover}
            alt=""
            className="h-48 w-48 rounded-2xl object-cover shadow-2xl glow"
          />
          <div className="flex-1">
            <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
              Playlist
            </div>
            <h1 className="mt-2 text-4xl sm:text-6xl font-semibold leading-tight">
              {playlist.title}
            </h1>
            <p className="mt-2 text-muted-foreground max-w-xl">{playlist.description}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              {tracks.length} faixas
            </p>
            <div className="mt-5 flex gap-2">
              <Button
                onClick={() => p.playTracks(tracks)}
                className="gradient-brand text-white glow hover:opacity-90 rounded-full h-11 px-6"
              >
                <Play className="h-4 w-4 mr-2" /> Tocar
              </Button>
              <Button
                variant="secondary"
                onClick={() => {
                  p.playTracks(tracks);
                  if (!p.shuffle) p.toggleShuffle();
                }}
                className="rounded-full h-11 px-6"
              >
                <Shuffle className="h-4 w-4 mr-2" /> Aleatório
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 sm:px-10 py-6 max-w-[1600px] mx-auto">
        <div className="rounded-2xl bg-card/50 p-2">
          {tracks.map((t: Track, i: number) => (
            <TrackRow
              key={t.id}
              track={t}
              index={i}
              onPlay={() => p.playTracks(tracks, i)}
            />
          ))}
        </div>
      </section>
    </div>
  );
}
