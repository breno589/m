import { createFileRoute, Link } from "@tanstack/react-router";
import { PLAYLISTS, TRACKS, GENRES, getPlaylistTracks } from "@/lib/catalog";
import { PlaylistTile } from "@/components/card-tile";
import { usePlayer } from "@/lib/player-store";
import { Play, TrendingUp, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import logoAsset from "@/assets/sonsplayer-logo.png.asset.json";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [
      { title: "SonsPlayer — Início" },
      {
        name: "description",
        content: "Descubra playlists, lançamentos e músicas em alta no SonsPlayer.",
      },
    ],
  }),
});

function Home() {
  const p = usePlayer();
  const featured = PLAYLISTS[0];
  const featuredTracks = getPlaylistTracks(featured.id);
  const trending = TRACKS.slice(0, 6);

  return (
    <div className="min-h-full">
      {/* Hero */}
      <section className="relative gradient-hero px-6 sm:px-10 pt-10 pb-16 overflow-hidden">
        <div className="max-w-6xl mx-auto grid md:grid-cols-[1.2fr_1fr] gap-10 items-center">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full glass px-3 py-1 text-xs">
              <Sparkles className="h-3 w-3 text-primary" />
              Recomendado para você
            </div>
            <h1 className="mt-4 text-4xl sm:text-6xl font-semibold leading-[1.05]">
              Sua música.<br />
              <span className="gradient-text">Seu ritmo.</span>
            </h1>
            <p className="mt-4 text-muted-foreground max-w-md">
              Descubra playlists curadas, artistas em alta e ouça suas músicas favoritas 
              em qualquer lugar, mesmo offline.
            </p>
            <div className="mt-6 flex gap-3">
              <Button
                onClick={() => p.playTracks(featuredTracks)}
                className="gradient-brand text-white glow hover:opacity-90 rounded-full h-11 px-6"
              >
                <Play className="h-4 w-4 mr-2" /> Tocar agora
              </Button>
              <Link to="/search">
                <Button variant="secondary" className="rounded-full h-11 px-6">
                  Explorar
                </Button>
              </Link>
            </div>
          </div>
          <div className="relative hidden md:block">
            <div className="absolute -inset-10 gradient-brand opacity-30 blur-3xl rounded-full" />
            <img
              src={logoAsset.url}
              alt="SonsPlayer — Música e som sem limites"
              className="relative rounded-3xl aspect-square object-cover shadow-2xl"
            />
          </div>
        </div>
      </section>

      <div className="px-6 sm:px-10 py-8 space-y-12 max-w-[1600px] mx-auto">
        {/* Gêneros */}
        <section>
          <h2 className="text-lg font-semibold mb-4">Explorar por gênero</h2>
          <div className="flex flex-wrap gap-2">
            {GENRES.map((g, i) => (
              <div
                key={g}
                className="px-4 py-2 rounded-full text-sm border border-white/10 hover:border-primary/60 transition-colors cursor-pointer"
                style={{
                  background: `linear-gradient(135deg, oklch(0.62 0.24 ${280 + i * 8} / 0.15), transparent)`,
                }}
              >
                {g}
              </div>
            ))}
          </div>
        </section>

        {/* Em alta */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" /> Em alta
            </h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {trending.map((t, i) => (
              <button
                key={t.id}
                onClick={() => p.playTracks(TRACKS, i)}
                className="text-left card-hover"
              >
                <div className="relative rounded-xl overflow-hidden aspect-square mb-2">
                  <img src={t.cover} alt="" className="h-full w-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent" />
                  <div className="absolute right-2 bottom-2 h-9 w-9 rounded-full gradient-brand grid place-items-center glow opacity-90">
                    <Play className="h-4 w-4 text-white ml-0.5" />
                  </div>
                </div>
                <div className="text-sm font-medium truncate">{t.title}</div>
                <div className="text-xs text-muted-foreground truncate">{t.artist}</div>
              </button>
            ))}
          </div>
        </section>

        {/* Playlists */}
        <section>
          <h2 className="text-lg font-semibold mb-4">Playlists para você</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
            {PLAYLISTS.map((pl) => (
              <PlaylistTile
                key={pl.id}
                id={pl.id}
                title={pl.title}
                description={pl.description}
                cover={pl.cover}
                onPlay={() => p.playTracks(getPlaylistTracks(pl.id))}
              />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
