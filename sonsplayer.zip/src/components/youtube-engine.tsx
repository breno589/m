/// <reference types="youtube" />
import { useEffect, useRef, useState } from "react";
import { usePlayer } from "@/lib/player-store";

declare global {
  interface Window {
    YT: typeof YT;
    onYouTubeIframeAPIReady?: () => void;
  }
}

let apiPromise: Promise<void> | null = null;
function loadYouTubeAPI() {
  if (apiPromise) return apiPromise;
  apiPromise = new Promise<void>((resolve) => {
    if (typeof window === "undefined") return;
    if (window.YT && window.YT.Player) return resolve();
    const tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    document.head.appendChild(tag);
    window.onYouTubeIframeAPIReady = () => resolve();
  });
  return apiPromise;
}

/** Player invisível que executa o áudio do YouTube. */
export function YouTubeEngine() {
  const containerRef = useRef<HTMLDivElement>(null);
  const playerRef = useRef<YT.Player | null>(null);
  const rafRef = useRef<number | null>(null);
  const [isOnline, setIsOnline] = useState(true);

  useEffect(() => {
    if (typeof window === "undefined") return;
    setIsOnline(navigator.onLine);
    const on = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  const {
    current,
    isPlaying,
    downloaded,
    _setPlayerRef,
    _onTick,
    _onEnd,
    _setPlaying,
  } = usePlayer();

  // Refs para sempre chamar os handlers mais recentes dentro do onStateChange
  // (evita closure obsoleta que ignora o fim da faixa e não avança).
  const onEndRef = useRef(_onEnd);
  const setPlayingRef = useRef(_setPlaying);
  const onTickRef = useRef(_onTick);
  useEffect(() => { onEndRef.current = _onEnd; }, [_onEnd]);
  useEffect(() => { setPlayingRef.current = _setPlaying; }, [_setPlaying]);
  useEffect(() => { onTickRef.current = _onTick; }, [_onTick]);

  useEffect(() => {
    let mounted = true;
    loadYouTubeAPI().then(() => {
      if (!mounted || !containerRef.current) return;
      const p = new window.YT.Player(containerRef.current, {
        height: "0",
        width: "0",
        playerVars: { controls: 0, disablekb: 1, playsinline: 1 },
        events: {
          onReady: () => {
            playerRef.current = p;
            _setPlayerRef(p);
          },
          onStateChange: (e: YT.OnStateChangeEvent) => {
            const S = window.YT.PlayerState;
            if (e.data === S.PLAYING) setPlayingRef.current(true);
            else if (e.data === S.PAUSED) setPlayingRef.current(false);
            else if (e.data === S.ENDED) onEndRef.current();
          },
        },
      });
    });
    return () => {
      mounted = false;
      if (rafRef.current) clearTimeout(rafRef.current);
      try {
        playerRef.current?.destroy();
      } catch {}
      _setPlayerRef(null);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Carrega vídeo ao trocar de faixa
  useEffect(() => {
    const p = playerRef.current;
    if (!p || !current) return;
    
    // Fallback logic: 
    // If offline and track is NOT downloaded, we can't play it.
    // If online, always try to load.
    if (!isOnline && !downloaded.has(current.id)) {
      console.warn("[offline] track not downloaded, cannot play");
      // Could show a notification or skip to next downloaded track
      return;
    }

    try {
      p.loadVideoById(current.videoId);
    } catch {}
  }, [current?.videoId, isOnline, downloaded]);

  // Sincroniza play/pause
  useEffect(() => {
    const p = playerRef.current;
    if (!p) return;
    try {
      if (isPlaying) p.playVideo();
      else p.pauseVideo();
    } catch {}
  }, [isPlaying, current?.videoId]);

  // Loop de progresso
  useEffect(() => {
    function tick() {
      const p = playerRef.current;
      if (p && typeof p.getCurrentTime === "function") {
        try {
          onTickRef.current(p.getCurrentTime() || 0, p.getDuration() || 0);
        } catch {}
      }
      rafRef.current = window.setTimeout(tick, 500) as unknown as number;
    }
    tick();
    return () => {
      if (rafRef.current) clearTimeout(rafRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      aria-hidden
      style={{
        position: "fixed",
        width: 0,
        height: 0,
        overflow: "hidden",
        pointerEvents: "none",
        opacity: 0,
      }}
    >
      <div ref={containerRef} />
    </div>
  );
}
