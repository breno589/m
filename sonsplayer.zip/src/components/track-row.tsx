import { Play, Heart, Download, Loader2, Pause, CheckCircle2, AlertCircle } from "lucide-react";
import { useState } from "react";
import { usePlayer, formatTime } from "@/lib/player-store";
import { cn } from "@/lib/utils";
import type { Track } from "@/lib/catalog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export function TrackRow({
  track,
  index,
  onPlay,
}: {
  track: Track;
  index: number;
  onPlay: () => void;
}) {
  const p = usePlayer();
  const isCurrent = p.current?.id === track.id;
  const isFav = p.favorites.has(track.id);
  const isDownloaded = p.downloaded.has(track.id);
  const hasError = p.downloadErrors?.has(track.id);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsDownloading(true);
    try {
      await p.toggleDownload(track);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div
      className={cn(
        "group grid grid-cols-[32px_1fr_auto_40px] sm:grid-cols-[40px_1fr_1fr_auto_40px] items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/5 transition-colors",
        isCurrent && "bg-white/5"
      )}
    >
      <button
        onClick={onPlay}
        className="text-muted-foreground text-sm w-8 h-8 grid place-items-center"
      >
        {isCurrent && p.isPlaying ? (
          <Pause className="h-4 w-4 text-primary" />
        ) : (
          <>
            <span className="group-hover:hidden tabular-nums">{index + 1}</span>
            <Play className="h-4 w-4 hidden group-hover:block" />
          </>
        )}
      </button>
      <div className="flex items-center gap-3 min-w-0">
        <img src={track.cover} alt="" className="h-10 w-10 rounded object-cover" />
        <div className="min-w-0">
          <div className={cn("truncate text-sm font-medium", isCurrent && "text-primary")}>
            {track.title}
          </div>
          <div className="truncate text-xs text-muted-foreground">{track.artist}</div>
        </div>
      </div>
      <div className="hidden sm:block truncate text-xs text-muted-foreground">
        {track.album ?? "—"}
      </div>
      <div className="flex items-center gap-1">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={handleDownload}
                className={cn(
                  "w-8 h-8 grid place-items-center transition-all",
                  isDownloaded ? "text-primary opacity-100" : 
                  hasError ? "text-destructive opacity-100" :
                  "opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-foreground"
                )}
                aria-label={isDownloaded ? "Remover download" : "Baixar"}
              >
                {isDownloading ? (
                  <Loader2 className="h-4 w-4 animate-spin text-primary" />
                ) : isDownloaded ? (
                  <CheckCircle2 className="h-4 w-4 fill-primary/10" />
                ) : hasError ? (
                  <AlertCircle className="h-4 w-4" />
                ) : (
                  <Download className="h-4 w-4" />
                )}
              </button>
            </TooltipTrigger>
            <TooltipContent side="top">
              <p className="text-xs">
                {isDownloading ? "Baixando..." : 
                 isDownloaded ? "Pronta offline" : 
                 hasError ? "Falha no download" : "Disponível para baixar"}
              </p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
      <button
        onClick={() => p.toggleFavorite(track.id)}
        className="w-8 h-8 grid place-items-center opacity-0 group-hover:opacity-100 transition-opacity"
        aria-label="Favoritar"
      >
        <Heart className={cn("h-4 w-4", isFav && "fill-primary text-primary opacity-100")} />
      </button>
      <div className="text-xs text-muted-foreground tabular-nums w-10 text-right">
        {track.duration ? formatTime(track.duration) : "—"}
      </div>
    </div>
  );
}
