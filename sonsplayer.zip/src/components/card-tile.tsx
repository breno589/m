import { Play } from "lucide-react";
import { Link } from "@tanstack/react-router";

export function PlaylistTile({
  id,
  title,
  description,
  cover,
  onPlay,
}: {
  id: string;
  title: string;
  description?: string;
  cover: string;
  onPlay?: (e: React.MouseEvent) => void;
}) {
  return (
    <Link
      to="/playlist/$id"
      params={{ id }}
      className="group block card-hover"
    >
      <div className="relative rounded-2xl overflow-hidden bg-card p-4">
        <div className="relative aspect-square rounded-xl overflow-hidden mb-3">
          <img
            src={cover}
            alt=""
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent" />
          {onPlay && (
            <button
              onClick={(e) => {
                e.preventDefault();
                onPlay(e);
              }}
              className="absolute right-3 bottom-3 h-11 w-11 rounded-full gradient-brand grid place-items-center opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all glow"
            >
              <Play className="h-5 w-5 text-white ml-0.5" />
            </button>
          )}
        </div>
        <div className="font-medium truncate">{title}</div>
        {description && (
          <div className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{description}</div>
        )}
      </div>
    </Link>
  );
}
