import { usePlayer, formatTime } from "@/lib/player-store";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import {
  Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, Repeat1,
  Heart, Volume2, ChevronUp, ChevronDown, ListMusic, X, Trash2,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function PlayerBar() {
  const p = usePlayer();
  if (!p.current) return null;
  const isFav = p.favorites.has(p.current.id);

  return (
    <>
      {/* Mini player fixo */}
      <div
        className={cn(
          "fixed bottom-0 inset-x-0 z-40 glass border-t",
          p.expanded && "pointer-events-none opacity-0"
        )}
      >
        <div className="mx-auto max-w-[1600px] px-3 sm:px-6 py-3 flex items-center gap-3 sm:gap-6">
          <button
            onClick={() => p.setExpanded(true)}
            className="flex items-center gap-3 min-w-0 flex-1 sm:flex-none sm:w-[260px] text-left group"
          >
            <img
              src={p.current.cover}
              alt=""
              className="h-12 w-12 rounded-lg object-cover shadow-md"
            />
            <div className="min-w-0">
              <div className="truncate font-medium text-sm">{p.current.title}</div>
              <div className="truncate text-xs text-muted-foreground">{p.current.artist}</div>
            </div>
          </button>

          <div className="flex-1 flex flex-col items-center gap-1.5">
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" onClick={p.toggleShuffle} className={cn(p.shuffle && "text-primary")}>
                <Shuffle className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" onClick={p.prev}>
                <SkipBack className="h-5 w-5" />
              </Button>
              <Button
                size="icon"
                onClick={p.toggle}
                className="h-10 w-10 rounded-full gradient-brand text-white glow hover:opacity-90"
              >
                {p.isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 ml-0.5" />}
              </Button>
              <Button variant="ghost" size="icon" onClick={p.next}>
                <SkipForward className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" onClick={p.cycleRepeat} className={cn(p.repeat !== "off" && "text-primary")}>
                {p.repeat === "one" ? <Repeat1 className="h-4 w-4" /> : <Repeat className="h-4 w-4" />}
              </Button>
            </div>
            <div className="hidden sm:flex w-full max-w-xl items-center gap-2">
              <span className="text-[10px] text-muted-foreground tabular-nums w-10 text-right">
                {formatTime(p.progress)}
              </span>
              <Slider
                value={[p.progress]}
                max={p.duration || 1}
                step={1}
                onValueChange={(v) => p.seek(v[0])}
                className="flex-1"
              />
              <span className="text-[10px] text-muted-foreground tabular-nums w-10">
                {formatTime(p.duration)}
              </span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-2 w-[260px] justify-end">
            <Button variant="ghost" size="icon" onClick={() => p.toggleFavorite(p.current!.id)}>
              <Heart className={cn("h-4 w-4", isFav && "fill-primary text-primary")} />
            </Button>
            <Volume2 className="h-4 w-4 text-muted-foreground" />
            <Slider
              value={[p.volume]}
              max={100}
              step={1}
              onValueChange={(v) => p.setVolume(v[0])}
              className="w-24"
            />
            <Button variant="ghost" size="icon" onClick={() => p.setQueueOpen(!p.queueOpen)} className={cn(p.queueOpen && "text-primary")} aria-label="Fila">
              <ListMusic className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => p.setExpanded(true)}>
              <ChevronUp className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Player expandido */}
      <div
        className={cn(
          "fixed inset-0 z-50 transition-all duration-500",
          p.expanded ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
        style={{
          background:
            `radial-gradient(60% 60% at 50% 0%, color-mix(in oklab, var(--brand) 35%, transparent), transparent 60%), var(--background)`,
        }}
      >
        <div className="absolute inset-0 backdrop-blur-3xl" style={{ background: "linear-gradient(180deg, rgba(13,13,13,0.4), rgba(13,13,13,0.85))" }} />
        <div className="relative h-full flex flex-col">
          <div className="flex items-center justify-between px-6 py-4">
            <Button variant="ghost" size="icon" onClick={() => p.setExpanded(false)}>
              <ChevronDown className="h-6 w-6" />
            </Button>
            <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
              Tocando agora
            </div>
            <Button variant="ghost" size="icon" onClick={() => p.setQueueOpen(!p.queueOpen)} className={cn(p.queueOpen && "text-primary")} aria-label="Fila">
              <ListMusic className="h-5 w-5" />
            </Button>
          </div>

          <div className="flex-1 grid place-items-center px-6">
            <div className="w-full max-w-md flex flex-col items-center gap-8">
              <div className="relative">
                <div className="absolute -inset-6 rounded-3xl gradient-brand opacity-40 blur-3xl" />
                <img
                  src={p.current.cover}
                  alt=""
                  className={cn(
                    "relative h-72 w-72 sm:h-80 sm:w-80 rounded-3xl object-cover shadow-2xl transition-transform duration-700",
                    p.isPlaying ? "scale-100" : "scale-95"
                  )}
                />
              </div>
              <div className="text-center w-full">
                <h2 className="text-3xl font-semibold">{p.current.title}</h2>
                <p className="text-muted-foreground mt-1">{p.current.artist}</p>
              </div>
              <div className="w-full">
                <Slider
                  value={[p.progress]}
                  max={p.duration || 1}
                  step={1}
                  onValueChange={(v) => p.seek(v[0])}
                />
                <div className="flex justify-between mt-2 text-xs text-muted-foreground tabular-nums">
                  <span>{formatTime(p.progress)}</span>
                  <span>{formatTime(p.duration)}</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Button variant="ghost" size="icon" onClick={p.toggleShuffle} className={cn(p.shuffle && "text-primary")}>
                  <Shuffle className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="icon" onClick={p.prev}>
                  <SkipBack className="h-7 w-7" />
                </Button>
                <Button
                  size="icon"
                  onClick={p.toggle}
                  className="h-16 w-16 rounded-full gradient-brand text-white glow hover:opacity-90"
                >
                  {p.isPlaying ? <Pause className="h-7 w-7" /> : <Play className="h-7 w-7 ml-1" />}
                </Button>
                <Button variant="ghost" size="icon" onClick={p.next}>
                  <SkipForward className="h-7 w-7" />
                </Button>
                <Button variant="ghost" size="icon" onClick={p.cycleRepeat} className={cn(p.repeat !== "off" && "text-primary")}>
                  {p.repeat === "one" ? <Repeat1 className="h-5 w-5" /> : <Repeat className="h-5 w-5" />}
                </Button>
              </div>
              <div className="flex items-center gap-4">
                <Button variant="ghost" size="icon" onClick={() => p.toggleFavorite(p.current!.id)}>
                  <Heart className={cn("h-5 w-5", isFav && "fill-primary text-primary")} />
                </Button>
                <div className="flex items-center gap-2 w-40">
                  <Volume2 className="h-4 w-4 text-muted-foreground" />
                  <Slider value={[p.volume]} max={100} step={1} onValueChange={(v) => p.setVolume(v[0])} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Painel de Fila */}
      <div
        className={cn(
          "fixed top-0 right-0 bottom-0 z-[60] w-full sm:w-[380px] glass border-l transition-transform duration-300",
          p.queueOpen ? "translate-x-0" : "translate-x-full"
        )}
        style={{ background: "linear-gradient(180deg, rgba(13,13,13,0.92), rgba(13,13,13,0.98))" }}
      >
        <div className="flex items-center justify-between px-4 h-14 border-b border-white/10">
          <div className="text-sm font-semibold">Fila de reprodução</div>
          <Button variant="ghost" size="icon" onClick={() => p.setQueueOpen(false)} aria-label="Fechar fila">
            <X className="h-4 w-4" />
          </Button>
        </div>
        <div className="overflow-y-auto h-[calc(100%-3.5rem)] pb-24">
          {p.queue.length === 0 ? (
            <p className="p-6 text-sm text-muted-foreground">A fila está vazia.</p>
          ) : (
            <ul className="p-2">
              {p.queue.map((t, i) => {
                const active = i === p.index;
                return (
                  <li
                    key={`${t.id}-${i}`}
                    className={cn(
                      "group flex items-center gap-3 px-2 py-2 rounded-lg cursor-pointer hover:bg-white/5",
                      active && "bg-white/5"
                    )}
                    onClick={() => p.playAt(i)}
                  >
                    <div className="w-6 text-center text-xs text-muted-foreground tabular-nums">
                      {active ? (
                        <span className="inline-block h-2 w-2 rounded-full bg-primary animate-pulse" />
                      ) : (
                        i + 1
                      )}
                    </div>
                    <img src={t.cover} alt="" className="h-10 w-10 rounded object-cover" />
                    <div className="min-w-0 flex-1">
                      <div className={cn("truncate text-sm", active && "text-primary font-medium")}>
                        {t.title}
                      </div>
                      <div className="truncate text-xs text-muted-foreground">{t.artist}</div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="opacity-0 group-hover:opacity-100"
                      onClick={(e) => {
                        e.stopPropagation();
                        p.removeFromQueue(i);
                      }}
                      aria-label="Remover da fila"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    </>
  );
}
