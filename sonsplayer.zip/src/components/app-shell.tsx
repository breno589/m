import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Search, Library, Sparkles, ListMusic, Heart } from "lucide-react";
import { cn } from "@/lib/utils";
import { PLAYLISTS } from "@/lib/catalog";
import type { ReactNode } from "react";
import logoAsset from "@/assets/sonsplayer-logo.png.asset.json";

const nav = [
  { to: "/", label: "Início", icon: Home },
  { to: "/search", label: "Pesquisar", icon: Search },
  { to: "/library", label: "Biblioteca", icon: Library },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex flex-1 pb-[92px]">
        {/* Sidebar */}
        <aside className="hidden lg:flex w-[260px] shrink-0 flex-col gap-2 p-4 border-r sticky top-0 h-screen">
          <Link to="/" className="flex items-center gap-2 px-3 py-4">
            <div className="relative h-10 w-10 rounded-xl overflow-hidden glow shrink-0">
              <img src={logoAsset.url} alt="SonsPlayer" className="h-full w-full object-cover" />
            </div>
            <div>
              <div className="font-display text-lg font-semibold leading-none">SonsPlayer</div>
              <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mt-1">
                Sua música. Seu ritmo.
              </div>
            </div>
          </Link>

          <nav className="flex flex-col gap-1 mt-2">
            {nav.map((item) => {
              const active = pathname === item.to;
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
                    active
                      ? "bg-accent text-accent-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="mt-6 px-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                Playlists
              </span>
              <Sparkles className="h-3.5 w-3.5 text-primary" />
            </div>
            <ul className="space-y-1 overflow-y-auto max-h-[45vh] pr-1">
              <li>
                <Link
                  to="/library"
                  className="flex items-center gap-2 px-2 py-1.5 rounded-md text-sm text-muted-foreground hover:text-foreground hover:bg-white/5"
                >
                  <Heart className="h-3.5 w-3.5" /> Favoritas
                </Link>
              </li>
              {PLAYLISTS.map((pl) => (
                <li key={pl.id}>
                  <Link
                    to="/playlist/$id"
                    params={{ id: pl.id }}
                    className="flex items-center gap-2 px-2 py-1.5 rounded-md text-sm text-muted-foreground hover:text-foreground hover:bg-white/5"
                  >
                    <ListMusic className="h-3.5 w-3.5" />
                    <span className="truncate">{pl.title}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        <main className="flex-1 min-w-0">{children}</main>
      </div>

      {/* Bottom nav mobile */}
      <nav className="lg:hidden fixed bottom-[76px] inset-x-0 z-30 border-t glass">
        <div className="grid grid-cols-3">
          {nav.map((item) => {
            const active = pathname === item.to;
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex flex-col items-center gap-1 py-2.5 text-[11px]",
                  active ? "text-primary" : "text-muted-foreground"
                )}
              >
                <Icon className="h-5 w-5" />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
