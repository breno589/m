// Catálogo mock — cada track referencia um vídeo do YouTube pelo videoId.
// A reprodução é feita via YouTube IFrame API.

export type Track = {
  id: string;
  videoId: string;
  title: string;
  artist: string;
  album?: string;
  cover: string;
  duration?: number; // segundos (opcional; obtemos da API quando toca)
  genre?: string;
};

export type Playlist = {
  id: string;
  title: string;
  description: string;
  cover: string;
  trackIds: string[];
};

const cover = (seed: string, hue = 280) =>
  `https://images.unsplash.com/photo-${seed}?auto=format&fit=crop&w=600&q=80&sat=-10&hue=${hue}`;

export const TRACKS: Track[] = [
  { id: "t1", videoId: "jfKfPfyJRdk", title: "Lofi Beats", artist: "Lofi Girl", album: "Study Session", cover: "https://i.ytimg.com/vi/jfKfPfyJRdk/maxresdefault.jpg", genre: "Lo-fi" },
  { id: "t2", videoId: "5qap5aO4i9A", title: "Chillhop Radio", artist: "Chillhop Music", album: "Endless Chill", cover: "https://i.ytimg.com/vi/5qap5aO4i9A/maxresdefault.jpg", genre: "Chillhop" },
  { id: "t3", videoId: "DWcJFNfaw9c", title: "Deep Focus", artist: "Ambient Worlds", album: "Deep Focus Vol. 1", cover: "https://i.ytimg.com/vi/DWcJFNfaw9c/maxresdefault.jpg", genre: "Ambient" },
  { id: "t4", videoId: "MYPVQccHhAQ", title: "Midnight Jazz", artist: "Cafe Music BGM", album: "Late Night", cover: "https://i.ytimg.com/vi/MYPVQccHhAQ/maxresdefault.jpg", genre: "Jazz" },
  { id: "t5", videoId: "n61ULEU7CO0", title: "Synthwave Drive", artist: "The 80s Guy", album: "Neon City", cover: "https://i.ytimg.com/vi/n61ULEU7CO0/maxresdefault.jpg", genre: "Synthwave" },
  { id: "t6", videoId: "4xDzrJKXOOY", title: "Summer Vibes", artist: "Sunset Lounge", album: "Golden Hour", cover: "https://i.ytimg.com/vi/4xDzrJKXOOY/maxresdefault.jpg", genre: "Chill" },
  { id: "t7", videoId: "7NOSDKb0HlU", title: "Electronic Pulse", artist: "Neon Waves", album: "Circuit", cover: "https://i.ytimg.com/vi/7NOSDKb0HlU/maxresdefault.jpg", genre: "Electronic" },
  { id: "t8", videoId: "lTRiuFIWV54", title: "Piano Reverie", artist: "Silent Keys", album: "Solo Piano", cover: "https://i.ytimg.com/vi/lTRiuFIWV54/maxresdefault.jpg", genre: "Classical" },
  { id: "t9", videoId: "hHW1oY26kxQ", title: "Coffee Shop", artist: "Cafe Vibes", album: "Morning Brew", cover: "https://i.ytimg.com/vi/hHW1oY26kxQ/maxresdefault.jpg", genre: "Jazz" },
  { id: "t10", videoId: "36YnV9STBqc", title: "Nature Sounds", artist: "Calm Forest", album: "Wilderness", cover: "https://i.ytimg.com/vi/36YnV9STBqc/maxresdefault.jpg", genre: "Ambient" },
  { id: "t11", videoId: "rUxyKA_-grg", title: "Retro Wave", artist: "VHS Dreams", album: "Nostalgia", cover: "https://i.ytimg.com/vi/rUxyKA_-grg/maxresdefault.jpg", genre: "Synthwave" },
  { id: "t12", videoId: "kgx4WGK0oNU", title: "Rainy Day", artist: "Weather Moods", album: "Storm", cover: "https://i.ytimg.com/vi/kgx4WGK0oNU/maxresdefault.jpg", genre: "Ambient" },
];

export const PLAYLISTS: Playlist[] = [
  {
    id: "p1",
    title: "Foco Total",
    description: "Beats calmos para trabalhar e estudar.",
    cover: "https://i.ytimg.com/vi/jfKfPfyJRdk/maxresdefault.jpg",
    trackIds: ["t1", "t3", "t8", "t10", "t12"],
  },
  {
    id: "p2",
    title: "Neon Nights",
    description: "Synthwave e retro vibes.",
    cover: "https://i.ytimg.com/vi/n61ULEU7CO0/maxresdefault.jpg",
    trackIds: ["t5", "t11", "t7"],
  },
  {
    id: "p3",
    title: "Café da Manhã",
    description: "Jazz suave e piano.",
    cover: "https://i.ytimg.com/vi/MYPVQccHhAQ/maxresdefault.jpg",
    trackIds: ["t4", "t8", "t9"],
  },
  {
    id: "p4",
    title: "Em Alta",
    description: "As mais tocadas da semana.",
    cover: "https://i.ytimg.com/vi/4xDzrJKXOOY/maxresdefault.jpg",
    trackIds: ["t6", "t2", "t7", "t5", "t1"],
  },
  {
    id: "p5",
    title: "Chill & Relax",
    description: "Para desacelerar.",
    cover: "https://i.ytimg.com/vi/hHW1oY26kxQ/maxresdefault.jpg",
    trackIds: ["t2", "t6", "t12", "t10"],
  },
  {
    id: "p6",
    title: "Descobertas",
    description: "Novidades curadas para você.",
    cover: "https://i.ytimg.com/vi/DWcJFNfaw9c/maxresdefault.jpg",
    trackIds: ["t3", "t7", "t11", "t8"],
  },
];

export const GENRES = ["Lo-fi", "Chillhop", "Ambient", "Jazz", "Synthwave", "Chill", "Electronic", "Classical"];

export function getTrack(id: string): Track | undefined {
  return TRACKS.find((t) => t.id === id);
}
export function getPlaylistTracks(pid: string): Track[] {
  const p = PLAYLISTS.find((x) => x.id === pid);
  if (!p) return [];
  return p.trackIds.map((id) => getTrack(id)).filter(Boolean) as Track[];
}
