import { createServerFn } from "@tanstack/react-start";
import type { Track } from "@/lib/catalog";

type YTSearchItem = {
  id: { videoId?: string };
  snippet: {
    title: string;
    channelTitle: string;
    thumbnails: {
      default?: { url: string };
      medium?: { url: string };
      high?: { url: string };
      maxres?: { url: string };
    };
  };
};

type YTSearchResponse = {
  items?: YTSearchItem[];
  nextPageToken?: string;
  error?: { message?: string };
};

export type YouTubeSearchPage = {
  tracks: Track[];
  nextPageToken: string | null;
};

function decodeHtml(s: string) {
  return s
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
}

export const searchYouTube = createServerFn({ method: "GET" })
  .inputValidator((input: { q: string; limit?: number; pageToken?: string }) => ({
    q: String(input?.q ?? "").slice(0, 120),
    limit: Math.min(Math.max(Number(input?.limit) || 20, 1), 25),
    pageToken: input?.pageToken ? String(input.pageToken).slice(0, 128) : "",
  }))
  .handler(async ({ data }): Promise<YouTubeSearchPage> => {
    const q = data.q.trim();
    if (!q) return { tracks: [], nextPageToken: null };
    const key = process.env.YOUTUBE_API_KEY;
    if (!key) throw new Error("YOUTUBE_API_KEY não configurada.");

    const url = new URL("https://www.googleapis.com/youtube/v3/search");
    url.searchParams.set("part", "snippet");
    url.searchParams.set("type", "video");
    url.searchParams.set("videoCategoryId", "10");
    url.searchParams.set("videoEmbeddable", "true");
    url.searchParams.set("maxResults", String(data.limit));
    url.searchParams.set("q", q);
    if (data.pageToken) url.searchParams.set("pageToken", data.pageToken);
    url.searchParams.set("key", key);

    const res = await fetch(url.toString());
    const json = (await res.json()) as YTSearchResponse;
    if (!res.ok) {
      console.error("[youtube] search failed", res.status, json);
      throw new Error(json.error?.message || `YouTube API erro ${res.status}`);
    }

    const items = json.items ?? [];
    const tracks = items
      .filter((it) => it.id?.videoId)
      .map((it): Track => {
        const vid = it.id.videoId!;
        const thumb =
          it.snippet.thumbnails.maxres?.url ||
          it.snippet.thumbnails.high?.url ||
          it.snippet.thumbnails.medium?.url ||
          it.snippet.thumbnails.default?.url ||
          `https://i.ytimg.com/vi/${vid}/hqdefault.jpg`;
        return {
          id: `yt_${vid}`,
          videoId: vid,
          title: decodeHtml(it.snippet.title),
          artist: decodeHtml(it.snippet.channelTitle),
          cover: thumb,
        };
      });

    return { tracks, nextPageToken: json.nextPageToken ?? null };
  });

export const getRelatedTracks = createServerFn({ method: "GET" })
  .inputValidator((input: { seedVideoId: string; artist?: string; title?: string; limit?: number }) => ({
    seedVideoId: String(input?.seedVideoId ?? "").slice(0, 32),
    artist: String(input?.artist ?? "").slice(0, 120),
    title: String(input?.title ?? "").slice(0, 120),
    limit: Math.min(Math.max(Number(input?.limit) || 20, 1), 25),
  }))
  .handler(async ({ data }): Promise<Track[]> => {
    if (!data.seedVideoId) return [];
    const key = process.env.YOUTUBE_API_KEY;
    if (!key) throw new Error("YOUTUBE_API_KEY não configurada.");

    const cleanArtist = data.artist.replace(/\s*-\s*Topic$/i, "").trim();

    // 1) Descobre o ESTILO/gênero da faixa semente via videos.list (topicDetails + tags).
    let genre = "";
    let seedTags: string[] = [];
    try {
      const vurl = new URL("https://www.googleapis.com/youtube/v3/videos");
      vurl.searchParams.set("part", "snippet,topicDetails");
      vurl.searchParams.set("id", data.seedVideoId);
      vurl.searchParams.set("key", key);
      const vres = await fetch(vurl.toString());
      const vjson = (await vres.json()) as {
        items?: Array<{
          snippet?: { tags?: string[]; title?: string; description?: string };
          topicDetails?: { topicCategories?: string[] };
        }>;
      };
      const item = vjson.items?.[0];
      seedTags = item?.snippet?.tags ?? [];
      const cats = item?.topicDetails?.topicCategories ?? [];
      // Ex.: https://en.wikipedia.org/wiki/Gospel_music -> "gospel music"
      const musicCat = cats.find((c) => /music|gospel|hop|rock|pop|jazz|blues|country|electronic|classical|reggae|funk|samba|sertanejo/i.test(c));
      if (musicCat) {
        const slug = decodeURIComponent(musicCat.split("/").pop() || "");
        genre = slug.replace(/_/g, " ").replace(/\bmusic\b/i, "").trim();
      }
      // Fallback: procura palavra-chave de gênero em tags/título.
      if (!genre) {
        const hay = [
          ...(seedTags || []),
          item?.snippet?.title ?? "",
          data.title,
        ]
          .join(" ")
          .toLowerCase();
        const styles = [
          "gospel", "worship", "louvor", "adoração", "sertanejo", "forró", "pagode",
          "samba", "funk", "trap", "rap", "hip hop", "rock", "pop", "mpb", "bossa nova",
          "reggae", "eletrônica", "eletronic", "house", "techno", "jazz", "blues",
          "country", "clássica", "classical", "metal", "punk", "indie", "lofi", "lo-fi",
          "k-pop", "kpop", "reggaeton", "salsa", "bolero", "arrocha", "piseiro",
        ];
        genre = styles.find((s) => hay.includes(s)) || "";
      }
    } catch (e) {
      console.warn("[youtube] videos.list falhou; caindo para artista", e);
    }

    // 2) Monta a query priorizando o ESTILO; adiciona o artista só como reforço quando existe.
    let q = "";
    if (genre && cleanArtist) q = `${genre} ${cleanArtist}`;
    else if (genre) q = `${genre} músicas`;
    else if (cleanArtist) q = cleanArtist;
    else q = data.title || "";
    if (!q) return [];

    const url = new URL("https://www.googleapis.com/youtube/v3/search");
    url.searchParams.set("part", "snippet");
    url.searchParams.set("type", "video");
    url.searchParams.set("videoCategoryId", "10");
    url.searchParams.set("videoEmbeddable", "true");
    url.searchParams.set("maxResults", String(data.limit));
    url.searchParams.set("q", q);
    url.searchParams.set("key", key);

    const res = await fetch(url.toString());
    const json = (await res.json()) as YTSearchResponse;
    if (!res.ok) {
      console.error("[youtube] related failed", res.status, json);
      return [];
    }
    const items = json.items ?? [];
    return items
      .filter((it) => it.id?.videoId && it.id.videoId !== data.seedVideoId)
      .map((it): Track => {
        const vid = it.id.videoId!;
        const thumb =
          it.snippet.thumbnails.maxres?.url ||
          it.snippet.thumbnails.high?.url ||
          it.snippet.thumbnails.medium?.url ||
          it.snippet.thumbnails.default?.url ||
          `https://i.ytimg.com/vi/${vid}/hqdefault.jpg`;
        return {
          id: `yt_${vid}`,
          videoId: vid,
          title: decodeHtml(it.snippet.title),
          artist: decodeHtml(it.snippet.channelTitle),
          cover: thumb,
        };
      });
  });
