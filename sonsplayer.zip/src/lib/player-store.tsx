/// <reference types="youtube" />
import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { Track } from "./catalog";
import { getRelatedTracks } from "./youtube.functions";
import { get, set, del, keys } from "idb-keyval";

type RepeatMode = "off" | "all" | "one";

type PlayerState = {
  queue: Track[];
  index: number;
  current: Track | null;
  isPlaying: boolean;
  progress: number; // segundos
  duration: number;
  volume: number; // 0..100
  shuffle: boolean;
  repeat: RepeatMode;
  expanded: boolean;
  queueOpen: boolean;
  favorites: Set<string>;
  downloaded: Set<string>;
  downloadErrors: Set<string>;
  storageUsage: number; // bytes
};

type PlayerActions = {
  playTracks: (tracks: Track[], startIndex?: number) => void;
  toggle: () => void;
  next: () => void;
  prev: () => void;
  seek: (s: number) => void;
  setVolume: (v: number) => void;
  toggleShuffle: () => void;
  cycleRepeat: () => void;
  toggleFavorite: (id: string) => void;
  setExpanded: (v: boolean) => void;
  setQueueOpen: (v: boolean) => void;
  playAt: (index: number) => void;
  removeFromQueue: (index: number) => void;
  playOffline: () => void;
  toggleDownload: (track: Track) => Promise<void>;
  clearDownloads: (filter?: { artist?: string; album?: string; id?: string }) => Promise<void>;
  // internos usados pelo componente do YT
  _setPlayerRef: (p: YT.Player | null) => void;
  _onTick: (progress: number, duration: number) => void;
  _onEnd: () => void;
  _setPlaying: (p: boolean) => void;
};

const Ctx = createContext<(PlayerState & PlayerActions) | null>(null);

const FAV_KEY = "sonsplayer:favs";

function loadFavs(): Set<string> {
  if (typeof window === "undefined") return new Set();
  try {
    const raw = localStorage.getItem(FAV_KEY);
    return new Set(raw ? (JSON.parse(raw) as string[]) : []);
  } catch {
    return new Set();
  }
}

export function PlayerProvider({ children }: { children: ReactNode }) {
  const [queue, setQueue] = useState<Track[]>([]);
  const [index, setIndex] = useState(0);
  const [isPlaying, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(80);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState<RepeatMode>("off");
  const [expanded, setExpanded] = useState(false);
  const [queueOpen, setQueueOpen] = useState(false);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [downloaded, setDownloaded] = useState<Set<string>>(new Set());
  const [downloadErrors, setDownloadErrors] = useState<Set<string>>(new Set());
  const [storageUsage, setStorageUsage] = useState(0);

  const playerRef = useRef<YT.Player | null>(null);

  useEffect(() => {
    setFavorites(loadFavs());
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    localStorage.setItem(FAV_KEY, JSON.stringify([...favorites]));
  }, [favorites]);

  const current = queue[index] ?? null;

  // Carrega IDs baixados ao iniciar
  useEffect(() => {
    keys().then((allKeys) => {
      const d = new Set(
        allKeys
          .filter((k) => typeof k === "string" && k.startsWith("dl_"))
          .map((k) => (k as string).replace("dl_", ""))
      );
      setDownloaded(d);
      setStorageUsage(d.size * 5 * 1024 * 1024);
    });
  }, []);

  const value = useMemo<PlayerState & PlayerActions>(
    () => ({
      queue,
      index,
      current,
      isPlaying,
      progress,
      duration,
      volume,
      shuffle,
      repeat,
      expanded,
      queueOpen,
      favorites,
      downloaded,
      downloadErrors,
      storageUsage,
      playTracks: (tracks, startIndex = 0) => {
        setQueue(tracks);
        setIndex(startIndex);
        setPlaying(true);
        setProgress(0);
        // Auto-rádio: enfileira faixas relacionadas ao tema da selecionada.
        const seed = tracks[startIndex];
        if (seed?.videoId) {
          const seedId = seed.id;
          getRelatedTracks({
            data: {
              seedVideoId: seed.videoId,
              artist: seed.artist,
              title: seed.title,
              limit: 20,
            },
          })
            .then((related) => {
              if (!related?.length) return;
              setQueue((prev) => {
                if (!prev.length || prev[0]?.id !== tracks[0]?.id) return prev;
                const seen = new Set(prev.map((t) => t.id));
                seen.add(seedId);
                const extras = related.filter((t) => !seen.has(t.id));
                if (!extras.length) return prev;
                return [...prev, ...extras];
              });
            })
            .catch((e) => console.warn("[radio] related fetch failed", e));
        }
      },
      toggle: () => {
        const p = playerRef.current;
        if (!p) return;
        if (isPlaying) p.pauseVideo();
        else p.playVideo();
      },
      next: () => {
        if (queue.length === 0) return;
        
        const isOnline = typeof navigator !== "undefined" ? navigator.onLine : true;

        if (repeat === "one") {
          playerRef.current?.seekTo(0, true);
          playerRef.current?.playVideo();
          return;
        }

        let ni = index;
        let attempts = 0;
        const maxAttempts = queue.length;

        // Tenta encontrar a próxima música válida (especialmente se estiver offline)
        do {
          ni = ni + 1;
          if (shuffle) ni = Math.floor(Math.random() * queue.length);
          
          if (ni >= queue.length) {
            if (repeat === "all") ni = 0;
            else {
              setPlaying(false);
              return;
            }
          }

          const candidate = queue[ni];
          // Se estiver online, qualquer uma serve. 
          // Se estiver offline, deve estar baixada.
          if (isOnline || downloaded.has(candidate.id)) {
            break;
          }
          
          attempts++;
        } while (attempts < maxAttempts);

        if (attempts >= maxAttempts && !isOnline) {
          console.warn("[offline] No more downloaded tracks in queue");
          setPlaying(false);
          return;
        }

        setIndex(ni);
        setPlaying(true);
        setProgress(0);
      },
      prev: () => {
        if (progress > 3) {
          playerRef.current?.seekTo(0, true);
          return;
        }
        const ni = Math.max(0, index - 1);
        setIndex(ni);
        setPlaying(true);
        setProgress(0);
      },
      seek: (s) => {
        playerRef.current?.seekTo(s, true);
        setProgress(s);
      },
      setVolume: (v) => {
        setVolumeState(v);
        playerRef.current?.setVolume(v);
      },
      toggleShuffle: () => setShuffle((s) => !s),
      cycleRepeat: () =>
        setRepeat((r) => (r === "off" ? "all" : r === "all" ? "one" : "off")),
      toggleFavorite: (id) =>
        setFavorites((prev) => {
          const s = new Set(prev);
          if (s.has(id)) s.delete(id);
          else s.add(id);
          return s;
        }),
      setExpanded,
      setQueueOpen,
      playAt: (i) => {
        if (i < 0 || i >= queue.length) return;
        setIndex(i);
        setPlaying(true);
        setProgress(0);
      },
      removeFromQueue: (i) => {
        setQueue((prev) => {
          if (i < 0 || i >= prev.length) return prev;
          const next = prev.slice();
          next.splice(i, 1);
          return next;
        });
        setIndex((cur) => {
          if (i < cur) return cur - 1;
          if (i === cur) {
            // remove atual: mantém índice (próxima entra no lugar) mas reinicia progresso
            setProgress(0);
            return cur;
          }
          return cur;
        });
      },
      playOffline: () => {
        // Filtra a fila apenas para o que está baixado se estiver sem internet
        if (queue.length > 0) {
          const dlTracks = queue.filter(t => downloaded.has(t.id));
          if (dlTracks.length > 0) {
            setQueue(dlTracks);
            setIndex(0);
            setPlaying(true);
          }
        }
      },
      toggleDownload: async (track) => {
        const key = `dl_${track.id}`;
        if (downloaded.has(track.id)) {
          await del(key);
          setDownloaded((prev) => {
            const next = new Set(prev);
            next.delete(track.id);
            return next;
          });
          setDownloadErrors((prev) => {
            const next = new Set(prev);
            next.delete(track.id);
            return next;
          });
          setStorageUsage((s) => Math.max(0, s - 5 * 1024 * 1024));
        } else {
          try {
            // Simula falha ocasional para demonstração de status "falhou"
            // if (Math.random() > 0.9) throw new Error("Network error");
            
            await set(key, track);
            setDownloaded((prev) => {
              const next = new Set(prev);
              next.add(track.id);
              return next;
            });
            setDownloadErrors((prev) => {
              const next = new Set(prev);
              next.delete(track.id);
              return next;
            });
            setStorageUsage((s) => s + 5 * 1024 * 1024);
          } catch (e) {
            console.error("[download] failed", e);
            setDownloadErrors((prev) => {
              const next = new Set(prev);
              next.add(track.id);
              return next;
            });
          }
        }
      },
      clearDownloads: async (filter: { artist?: string; album?: string; id?: string } | undefined) => {
        const allKeys = await keys();
        const dlKeys = allKeys.filter((k) => typeof k === "string" && k.startsWith("dl_"));
        
        let keysToRemove = dlKeys as string[];

        if (filter) {
          const items = await Promise.all(dlKeys.map(async (k) => ({ key: k as string, track: await get<Track>(k) })));
          keysToRemove = items
            .filter(({ track }) => {
              if (!track) return false;
              if (filter.id && track.id === filter.id) return true;
              if (filter.artist && track.artist === filter.artist) return true;
              if (filter.album && track.album === filter.album) return true;
              return false;
            })
            .map(({ key }) => key);
        }

        await Promise.all(keysToRemove.map((k) => del(k)));
        
        // Atualiza estado local
        const removedCount = keysToRemove.length;
        const removedIds = new Set(keysToRemove.map(k => k.replace("dl_", "")));

        setDownloaded((prev) => {
          const next = new Set(prev);
          removedIds.forEach(id => next.delete(id));
          return next;
        });
        setDownloadErrors((prev) => {
          const next = new Set(prev);
          removedIds.forEach(id => next.delete(id));
          return next;
        });
        setStorageUsage((s) => Math.max(0, s - removedCount * 5 * 1024 * 1024));
      },
      _setPlayerRef: (p) => {
        playerRef.current = p;
        if (p) p.setVolume(volume);
      },
      _onTick: (p, d) => {
        setProgress(p);
        if (d && d !== duration) setDuration(d);
      },
      _onEnd: () => {
        if (repeat === "one") {
          playerRef.current?.seekTo(0, true);
          playerRef.current?.playVideo();
          return;
        }

        const isOnline = typeof navigator !== "undefined" ? navigator.onLine : true;
        let ni = index;
        let attempts = 0;
        const maxAttempts = queue.length;

        do {
          ni = ni + 1;
          if (shuffle) ni = Math.floor(Math.random() * queue.length);
          
          if (ni >= queue.length) {
            if (repeat === "all") ni = 0;
            else {
              setPlaying(false);
              return;
            }
          }

          const candidate = queue[ni];
          if (isOnline || downloaded.has(candidate.id)) {
            break;
          }
          attempts++;
        } while (attempts < maxAttempts);

        if (attempts >= maxAttempts && !isOnline) {
          setPlaying(false);
          return;
        }

        setIndex(ni);
        setPlaying(true);
        setProgress(0);
      },
      _setPlaying: setPlaying,
    }),
    [queue, index, current, isPlaying, progress, duration, volume, shuffle, repeat, expanded, queueOpen, favorites, downloaded, downloadErrors, storageUsage]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function usePlayer() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("usePlayer must be used inside PlayerProvider");
  return ctx;
}

export function formatTime(sec: number) {
  if (!isFinite(sec) || sec < 0) return "0:00";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}
