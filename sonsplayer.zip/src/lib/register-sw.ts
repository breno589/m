// Registro guardado do Service Worker.
// - Nunca registra em dev, iframe, previews Lovable ou quando ?sw=off está na URL.
// - Em qualquer contexto proibido, desregistra SWs existentes para não servir
//   HTML velho.
const SW_URL = "/sw.js";
const HOST_BLOCKLIST_PREFIXES = ["id-preview--", "preview--"];
const HOST_BLOCKLIST_SUFFIXES = [
  "lovableproject.com",
  "lovableproject-dev.com",
  "beta.lovable.dev",
];
const HOST_BLOCKLIST_EXACT = [
  "lovableproject.com",
  "lovableproject-dev.com",
  "beta.lovable.dev",
];

function isForbiddenContext(): boolean {
  if (typeof window === "undefined") return true;
  if (!("serviceWorker" in navigator)) return true;
  if (!import.meta.env.PROD) return true;
  try {
    if (window.self !== window.top) return true;
  } catch {
    return true;
  }
  const host = window.location.hostname;
  if (HOST_BLOCKLIST_EXACT.includes(host)) return true;
  if (HOST_BLOCKLIST_PREFIXES.some((p) => host.startsWith(p))) return true;
  if (HOST_BLOCKLIST_SUFFIXES.some((s) => host.endsWith(s))) return true;
  const params = new URLSearchParams(window.location.search);
  if (params.get("sw") === "off") return true;
  return false;
}

async function unregisterMatching(): Promise<void> {
  if (typeof navigator === "undefined" || !("serviceWorker" in navigator)) return;
  try {
    const regs = await navigator.serviceWorker.getRegistrations();
    await Promise.all(
      regs
        .filter((r) => {
          const url = r.active?.scriptURL || r.installing?.scriptURL || r.waiting?.scriptURL || "";
          return url.endsWith(SW_URL);
        })
        .map((r) => r.unregister()),
    );
  } catch {
    /* noop */
  }
}

export async function registerSonsPlayerSW(): Promise<void> {
  if (isForbiddenContext()) {
    await unregisterMatching();
    return;
  }
  try {
    await navigator.serviceWorker.register(SW_URL, { scope: "/" });
  } catch (err) {
    console.warn("[pwa] SW registration failed", err);
  }
}
