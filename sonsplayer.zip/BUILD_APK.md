# Guia Completo: Gerar o APK do SonsPlayer

Este guia mostra como gerar o arquivo `.apk` do SonsPlayer a partir do seu código-fonte usando **Capacitor** + **Android Studio**. O projeto já está configurado para carregar o site publicado em `https://sonsplayer.lovable.app`, então o APK funciona como um "wrapper" nativo: depois de instalado, ele se atualiza sozinho sempre que você clicar em **Publish → Update** no Lovable.

---

## O que você vai precisar (instale uma vez só)

| Ferramenta | Para que serve | Link / Comando |
|------------|--------------|----------------|
| Node.js 20+ | Ambiente JavaScript | https://nodejs.org |
| Bun (recomendado) | Instalar pacotes e rodar scripts | `npm install -g bun` |
| Android Studio | Compilar o APK nativo | https://developer.android.com/studio |
| JDK 17 | Compilação Java | Instalado automaticamente com o Android Studio |

> **Dica:** se você já usa npm, pode substituir `bun` por `npm run` ou `npx`. Os comandos abaixo usam `bun` por ser mais rápido.

---

## 1. Baixar o projeto

Você pode clonar o repositório do GitHub (botão **GitHub → Connect** no Lovable) ou baixar o ZIP.

```bash
# Usando Git
git clone https://github.com/seu-usuario/seu-repositorio.git sonsplayer
cd sonsplayer

# Ou, se baixou o ZIP, extraia e abra a pasta no terminal
```

---

## 2. Instalar as dependências

Isso instala o Capacitor, os plugins e todas as bibliotecas do projeto.

```bash
bun install
```

Se estiver usando npm:

```bash
npm install
```

---

## 3. Adicionar a plataforma Android (só na primeira vez)

Este comando cria a pasta `android/` com o projeto nativo. **Não é necessário repetir** depois que ela já existe.

```bash
bunx cap add android
```

Saída esperada:

```
[success] android platform added!
```

> Se a pasta `android/` já existir, pule este passo e vá direto para o **Passo 4**.

---

## 4. Sincronizar o Capacitor com o Android

Sempre que você alterar:

- `capacitor.config.ts`
- `package.json` (plugins do Capacitor)
- A pasta `dist/` ou `public/`

rode o comando de sync para copiar as mudanças para o projeto Android:

```bash
bunx cap sync android
```

Saída esperada:

```
[info] Found 1 Capacitor plugin for android:
       @capacitor/app@...
[info] Sync finished in 0.5s
```

---

## 5. Abrir o Android Studio

```bash
bunx cap open android
```

O Android Studio abrirá na pasta `android/`. Aguarde a sincronização do Gradle (barra de progresso no rodapé). Isso pode levar alguns minutos na primeira vez.

---

## 6. Gerar o APK de debug

No Android Studio, siga os passos exatos:

1. Certifique-se de que **nenhum erro** aparece no painel inferior (Build / Sync).
2. No menu superior, clique em **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. Aguarde o Gradle terminar a build.
4. Quando aparecer um toast no canto inferior direito, clique em **locate**.

O APK de debug será aberto na pasta:

```
android/app/build/outputs/apk/debug/app-debug.apk
```

> Esse APK é só para testes. Ele pode mostrar o aviso "App não verificado" ao instalar.

---

## 7. Instalar no celular Android

### Opção A: pelo cabo USB

1. Conecte o celular no computador.
2. Ative a **Depuração USB** nas opções de desenvolvedor do celular.
3. No Android Studio, clique no botão de play (▶) com o celular selecionado.

### Opção B: copiando o arquivo

1. Copie o `app-debug.apk` para o celular (USB, Google Drive, WhatsApp Web, etc.).
2. No celular, abra o arquivo.
3. Toque em **Instalar** e permita **instalar de fontes desconhecidas** se pedir.
4. Pronto — o SonsPlayer aparece na gaveta de apps com o logo.

---

## APK assinado para distribuir (release / Play Store)

Para publicar na Play Store ou distribuir sem o aviso de "fonte desconhecida", você precisa de um APK ou AAB assinado.

No Android Studio:

1. **Build → Generate Signed Bundle / APK...**
2. Selecione **APK** (mais simples) ou **Android App Bundle** (obrigatório para a Play Store).
3. Clique em **Create new keystore** e preencha:
   - **Key store path:** local seguro para salvar o arquivo `.jks`.
   - **Password:** uma senha forte.
   - **Key alias:** `sonsplayer_key`.
   - **Validity:** 25 anos.
4. Clique em **Next** e escolha a variant **release**.
5. Aguarde a build.

Saída esperada:

- APK: `android/app/release/app-release.apk`
- AAB: `android/app/release/app-release.aab`

> ⚠️ **Guarde a senha e o arquivo da keystore com segurança.** Sem eles você não consegue atualizar o app na Play Store no futuro.

---

## Comandos úteis do Capacitor

```bash
# Sincronizar plataforma Android
bunx cap sync android

# Abrir o Android Studio
bunx cap open android

# Copiar apenas a webview (útil para builds rápidos sem mudar plugins)
bunx cap copy android

# Atualizar os plugins nativos
bunx cap update android

# Limpar a plataforma Android e recriar (caso dê erro grave)
rm -rf android
bunx cap add android
bunx cap sync android
```

---

## Como o app se atualiza sozinho

No `capacitor.config.ts` o app está configurado para carregar:

```ts
url: "https://sonsplayer.lovable.app"
```

Isso significa que:

- A primeira abertura carrega o site publicado.
- As próximas vezes, o app sempre busca a versão mais recente do site.
- Você **não precisa gerar um novo APK** para cada mudança de layout ou função.

Apenas gere um novo APK quando:

- Mudar o ícone nativo.
- Mudar o nome do app.
- Mudar o App ID.
- Adicionar/remover plugins nativos do Capacitor.

---

## Trocar o App ID

O identificador atual é `app.sonsplayer.mobile`. Se quiser mudar, edite `capacitor.config.ts` **antes** do `bunx cap add android`:

```ts
const config: CapacitorConfig = {
  appId: "seu.novo.id.aqui",
  appName: "SonsPlayer",
  // ...
};
```

Depois de `cap add android`, a mudança também deve ser feita em:

```
android/app/build.gradle
```

 procure a linha `applicationId` e atualize.

---

## Trocar o ícone do app

1. No Android Studio, clique com o botão direito na pasta `android/app`.
2. Escolha **New → Image Asset**.
3. Selecione um PNG ou SVG do logo do SonsPlayer.
4. Configure o fundo e o ícone de primeiro plano.
5. Clique em **Next → Finish**.

O Android Studio gera automaticamente todos os tamanhos necessários em:

```
android/app/src/main/res/mipmap-*/
```

---

## Solução de problemas comuns

| Problema | Causa provável | Solução |
|----------|---------------|---------|
| `Gradle sync failed` | SDK ou JDK faltando | No Android Studio, vá em **SDK Manager** e instale o Android SDK 14 e o JDK 17. |
| `bunx cap not found` | Bun não instalado | Rode `npm install -g bun` ou use `npx cap` no lugar de `bunx cap`. |
| App abre em branco | URL do site inacessível | Verifique se você publicou o app em `https://sonsplayer.lovable.app`. |
| APK não instala | APK debug em celular com restrições | Habilite "Fontes desconhecidas" ou use um APK assinado. |
| Ícone não aparece | `android/` foi criado sem o asset | Rode `bunx cap copy android` depois de substituir os ícones. |

---

## Resumo rápido (para copiar e colar)

```bash
# 1. Instalar dependências
bun install

# 2. Adicionar Android (só primeira vez)
bunx cap add android

# 3. Sincronizar
bunx cap sync android

# 4. Abrir no Android Studio
bunx cap open android

# 5. No Android Studio: Build → Build Bundle(s) / APK(s) → Build APK(s)
```

---

## Precisa de ajuda?

Se algum passo der erro, me envie a mensagem exibida no Android Studio ou no terminal. Assim consigo te guiar na correção.
