import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "app.sonsplayer.mobile",
  appName: "SonsPlayer",
  webDir: "dist",
  server: {
    // Modo 1: o APK carrega o site publicado.
    // Sempre que você atualizar no Lovable, o app pega a nova versão sozinho.
    url: "https://sonsplayer.lovable.app",
    cleartext: false,
    androidScheme: "https",
  },
  android: {
    allowMixedContent: false,
    backgroundColor: "#0D0D0D",
  },
  plugins: {
    App: {
      // Configuração para interceptar links do domínio sonsplayer.lovable.app
      // Isso permite que o app abra automaticamente ao clicar em links
    },
  },
};

export default config;
