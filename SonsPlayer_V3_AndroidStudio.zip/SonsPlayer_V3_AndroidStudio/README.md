# SonsPlayer V3 — Android Studio

Projeto Kotlin/Android com **biblioteca de músicas do aparelho**, **importação de arquivos de áudio**, **links HTTPS de áudio autorizados**, **player Media3 em segundo plano**, **controles na notificação**, **favoritos**, **playlists** e **consulta opcional de playlists públicas do YouTube**.

> **Entrega:** código-fonte organizado para importação no Android Studio. **Não é um APK já compilado nem foi testado em dispositivo**: o ambiente de preparação não possui Android SDK/Gradle nem acesso ao repositório de dependências. É necessário fazer o build e validar no Android Studio.

## Como gerar o APK

1. Abra o **Android Studio** em um PC (Windows, Linux ou macOS).
2. Extraia o ZIP e use **File > Open** na pasta `SonsPlayer_V3_AndroidStudio` (a que contém `settings.gradle.kts`).
3. Instale o **Android SDK Platform 36**, o JDK 17 ou superior compatível e os Build Tools solicitados pelo Android Studio.
4. Aguarde **Sync Project with Gradle Files**. Requer conexão à internet para baixar Gradle e bibliotecas AndroidX.
5. Conecte um celular com depuração USB ativada ou inicie um emulador; clique **Run** para testar.
6. Para criar o APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. O debug APK normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.
7. Copie o APK para o celular e instale-o. O sistema pode solicitar autorização para instalar apps de fora da loja.

**Gradle:** Este projeto inclui um *launcher de bootstrap* mínimo (`gradle-wrapper.jar` / `gradlew`) gerado especificamente para distribuir o Gradle 8.13. Ele usa a URL HTTPS oficial indicada em `gradle/wrapper/gradle-wrapper.properties`. Para distribuição profissional/repositório compartilhado, substitua-o pelo wrapper oficial executando `gradle wrapper --gradle-version 8.13` com um Gradle já instalado. Nunca introduza fontes de distribuição desconhecidas.

## Usar o SonsPlayer

- Na primeira abertura, autorize o acesso às músicas locais para mostrar o catálogo do celular.
- Toque em **+ > Importar arquivo** para escolher MP3, M4A/AAC e outros áudios compatíveis usando o seletor do Android. Isto também funciona sem conceder permissão para toda a biblioteca.
- Toque em uma música para iniciar a fila do catálogo/playlist atual. Use ▶, ❚❚, anterior, próxima e a barra de progresso.
- Com áudio em execução, apague a tela: `MediaSessionService` gerencia reprodução/controles na notificação. O Android pode interromper áudio em situações de economia de bateria agressiva, permissões revogadas ou erro no arquivo.
- Toque em **♡** para favoritar, em **Playlists > + Criar lista** para criar uma lista e em **⋮ > Adicionar a uma playlist** para preenchê-la. Tudo é salvo localmente com `SharedPreferences`.
- **+ > Adicionar URL HTTPS de áudio** aceita um arquivo MP3/AAC ou fluxo de áudio HLS sobre HTTPS, desde que haja autorização. É necessário um endereço de mídia real e acessível, não uma página HTML.
- Na tela **YouTube**, informe o link ou ID de uma playlist. Sem chave de API é possível **abrir a playlist no YouTube**. Para listar até 200 vídeos públicos no SonsPlayer, informe uma chave válida da **YouTube Data API v3** (ativada no Google Cloud Console). Clique nos resultados para abrir cada vídeo no aplicativo oficial ou navegador.

## Limitações e boas práticas

- A **YouTube Data API v3 não fornece URL direta de áudio**. O aplicativo não extrai áudio de vídeos, não faz download deles e não os toca em segundo plano fora do player oficial.
- O player funciona **offline** para arquivos locais e importados com acesso persistente. Streams HTTPS dependem de conexão; **não existe download automático para offline**.
- O seletor de arquivos `ACTION_OPEN_DOCUMENT` tenta persistir permissão para arquivos importados. Se o arquivo for movido/removido ou o provedor revogar o acesso, será preciso importá-lo novamente.
- Chaves digitadas da API do YouTube não são salvas em `SharedPreferences`; **não embuta chaves privadas sem restrições em apps distribuídos**.
- A versão inclui um layout inicial moderno, sem artwork individual das faixas, com títulos e artistas fornecidos pelo Android.
- As playlists são armazenadas no aparelho e não há sincronização em nuvem.
- Em Android 13+, a permissão `READ_MEDIA_AUDIO` é solicitada para mostrar toda a biblioteca; nas versões anteriores, `READ_EXTERNAL_STORAGE` (somente até API 32).

## Versões e estrutura

- Android Gradle Plugin: **8.13.2**; Gradle: **8.13**; Kotlin: **2.3.20**; `compileSdk=36`, `minSdk=26`, `targetSdk=34`.
- Media3 ExoPlayer + Session + HLS: **1.11.1**.

```
app/src/main/
  AndroidManifest.xml
  java/com/sonsplayer/app/
    MainActivity.kt              # interface, permissões, fila e ações
    MusicPlaybackService.kt      # Media3/ExoPlayer em segundo plano
    LibraryStore.kt              # MediaStore, favoritos, listas, importações
    Track.kt                     # modelo de música
    TrackAdapter.kt              # itens da biblioteca
    PlaylistAdapter.kt           # itens de playlists
    YouTubePlaylistActivity.kt   # consulta oficial YouTube Data API v3
  res/layout/                   # telas e linhas da biblioteca
  res/drawable/                 # fundos e ícone
  res/values/                   # tema, cores e estilos
```

## Erros comuns

- **Gradle sync failed / SDK não encontrado:** instale Android SDK Platform 36 e configure o caminho do SDK no Android Studio.
- **Sem músicas:** conceda permissão e teste um MP3 local com **+ > Importar arquivo**.
- **Stream não toca:** teste a URL HTTPS direta, certificado válido, tipo suportado, e necessidade de autorização do servidor.
- **YouTube falha:** confirme que a YouTube Data API v3 está habilitada, que a chave é válida e que a playlist é pública.
- **Sem áudio em segundo plano:** confirme que o app está reproduzindo um arquivo válido e verifique as restrições de bateria do fabricante.

Referências oficiais:
- https://developer.android.com/media/media3/session/background-playback
- https://developer.android.com/jetpack/androidx/releases/media3
- https://developers.google.com/youtube/v3/docs/playlistItems/list

## Alternativa: gerar o APK pela nuvem (sem Android Studio no celular)

O projeto também contém `.github/workflows/build-apk.yml`. Se você publicar **todos** os arquivos em um repositório do GitHub (incluindo a pasta oculta `.github`), abra **Actions > Gerar APK SonsPlayer > Run workflow**. Quando o workflow terminar com sucesso, baixe o artefato `SonsPlayer-V3-debug-apk`, descompacte-o e instale o `app-debug.apk` no Android. Isso depende de uma execução bem-sucedida do GitHub Actions e não foi executado neste ambiente.
