package com.sonsplayer.app

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.View
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.common.util.concurrent.ListenableFuture
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private enum class Tab { ALL, FAVORITES, PLAYLISTS }
    private lateinit var libraryStore: LibraryStore
    private lateinit var songAdapter: TrackAdapter
    private lateinit var playlistAdapter: PlaylistAdapter
    private lateinit var recycler: RecyclerView
    private lateinit var emptyView: TextView
    private lateinit var sectionTitle: TextView
    private lateinit var newPlaylist: TextView
    private lateinit var playerTitle: TextView
    private lateinit var playerArtist: TextView
    private lateinit var favoriteButton: TextView
    private lateinit var playPause: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var currentTime: TextView
    private lateinit var totalTime: TextView
    private lateinit var tabAll: TextView
    private lateinit var tabFavorites: TextView
    private lateinit var tabPlaylists: TextView

    private var currentTab = Tab.ALL
    private var openedPlaylist: String? = null
    private var library: List<Track> = emptyList()
    private var filter = ""
    private var loadGeneration = 0
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val progressHandler = Handler(Looper.getMainLooper())
    private var userScrubbing = false

    private val progressTask = object : Runnable {
        override fun run() {
            updatePlayerProgress()
            progressHandler.postDelayed(this, 450)
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            updatePlayerUi()
        }
        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(this@MainActivity,
                "Não foi possível reproduzir o áudio. Verifique o arquivo ou link HTTPS.", Toast.LENGTH_LONG).show()
        }
    }

    private val permissionRequest = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) toast("Sem permissão, use + para importar arquivos manualmente.")
        scanLibrary()
    }

    private val filePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) { /* Alguns provedores não permitem persistência. */ }
            val title = try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
            } catch (_: Exception) { null }
            libraryStore.addImported(Track(uri.toString(),
                (title ?: "Áudio importado").substringBeforeLast('.'), "Arquivo importado", "imported"))
            scanLibrary()
            toast("Música adicionada à biblioteca")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        libraryStore = LibraryStore(this)
        bindViews()
        configureAdapters()
        configureActions()
        configurePlayer()
        refreshContent()
        if (libraryStore.hasMediaPermission()) scanLibrary()
        else permissionRequest.launch(libraryStore.permissionName())

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (openedPlaylist != null) {
                    openedPlaylist = null
                    refreshContent()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun bindViews() {
        recycler = findViewById(R.id.recyclerSongs)
        emptyView = findViewById(R.id.emptyState)
        sectionTitle = findViewById(R.id.sectionTitle)
        newPlaylist = findViewById(R.id.btnNewPlaylist)
        playerTitle = findViewById(R.id.playerTitle)
        playerArtist = findViewById(R.id.playerArtist)
        favoriteButton = findViewById(R.id.btnPlayerFavorite)
        playPause = findViewById(R.id.btnPlayPause)
        seekBar = findViewById(R.id.playerSeek)
        currentTime = findViewById(R.id.timeCurrent)
        totalTime = findViewById(R.id.timeDuration)
        tabAll = findViewById(R.id.tabAll)
        tabFavorites = findViewById(R.id.tabFavorites)
        tabPlaylists = findViewById(R.id.tabPlaylists)
        recycler.layoutManager = LinearLayoutManager(this)
    }

    private fun configureAdapters() {
        songAdapter = TrackAdapter(
            isFavorite = { it in libraryStore.favorites },
            onPlay = { _, index -> playQueue(songAdapter.current(), index) },
            onFavorite = { track ->
                libraryStore.toggleFavorite(track.uri)
                refreshContent()
                updatePlayerUi()
            },
            onMenu = { view, track -> showTrackOptions(view, track) }
        )
        playlistAdapter = PlaylistAdapter(
            onOpen = { name -> openedPlaylist = name; refreshContent() },
            onOptions = { view, name ->
                PopupMenu(this, view).apply {
                    menu.add("Excluir playlist")
                    setOnMenuItemClickListener {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("Excluir '$name'?")
                            .setMessage("As músicas originais não serão apagadas.")
                            .setNegativeButton("Cancelar", null)
                            .setPositiveButton("Excluir") { _, _ ->
                                libraryStore.deletePlaylist(name)
                                if (openedPlaylist == name) openedPlaylist = null
                                refreshContent()
                            }.show()
                        true
                    }
                }.show()
            }
        )
    }

    private fun configureActions() {
        findViewById<EditText>(R.id.searchInput).addTextChangedListener {
            filter = it?.toString()?.trim()?.lowercase(Locale.getDefault()).orEmpty()
            refreshContent()
        }
        tabAll.setOnClickListener { currentTab = Tab.ALL; openedPlaylist = null; refreshContent() }
        tabFavorites.setOnClickListener { currentTab = Tab.FAVORITES; openedPlaylist = null; refreshContent() }
        tabPlaylists.setOnClickListener { currentTab = Tab.PLAYLISTS; openedPlaylist = null; refreshContent() }
        findViewById<View>(R.id.btnAdd).setOnClickListener { addAudioOptions() }
        findViewById<View>(R.id.btnYoutube).setOnClickListener {
            startActivity(Intent(this, YouTubePlaylistActivity::class.java))
        }
        newPlaylist.setOnClickListener {
            if (openedPlaylist != null) {
                openedPlaylist = null
                refreshContent()
            } else showCreatePlaylist()
        }
        favoriteButton.setOnClickListener {
            val id = controller?.currentMediaItem?.mediaId.orEmpty()
            if (id.isNotBlank()) {
                libraryStore.toggleFavorite(id)
                refreshContent()
                updatePlayerUi()
            }
        }
        playPause.setOnClickListener {
            controller?.let { player ->
                if (player.isPlaying) player.pause()
                else if (player.mediaItemCount > 0) player.play()
                else if (library.isNotEmpty()) playQueue(library, 0)
            } ?: toast("Conectando ao player...")
        }
        findViewById<View>(R.id.btnPrevious).setOnClickListener {
            controller?.seekToPreviousMediaItem()
        }
        findViewById<View>(R.id.btnNext).setOnClickListener {
            controller?.seekToNextMediaItem()
        }
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) currentTime.text = formatTime(progress.toLong() * 1000L)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) { userScrubbing = true }
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                controller?.takeIf { it.duration > 0 && it.duration != C.TIME_UNSET }
                    ?.seekTo(seekBar.progress.toLong() * 1000L)
                userScrubbing = false
            }
        })
    }

    private fun configurePlayer() {
        val token = SessionToken(this, ComponentName(this, MusicPlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            if (isDestroyed || isFinishing) return@addListener
            try {
                controller = future.get()
                controller?.addListener(playerListener)
                updatePlayerUi()
            } catch (_: Exception) {
                toast("Falha ao conectar o player de segundo plano")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun scanLibrary() {
        val generation = ++loadGeneration
        thread(name = "sonslibrary-scanner") {
            val loaded = libraryStore.loadAll()
            runOnUiThread {
                if (generation == loadGeneration && !isFinishing && !isDestroyed) {
                    library = loaded
                    refreshContent()
                    updatePlayerUi()
                }
            }
        }
    }

    private fun refreshContent() {
        tabAll.setTextColor(ContextCompat.getColor(this, if (currentTab == Tab.ALL) R.color.accent else R.color.secondary_text))
        tabFavorites.setTextColor(ContextCompat.getColor(this, if (currentTab == Tab.FAVORITES) R.color.accent else R.color.secondary_text))
        tabPlaylists.setTextColor(ContextCompat.getColor(this, if (currentTab == Tab.PLAYLISTS) R.color.accent else R.color.secondary_text))
        val opened = openedPlaylist
        val showingPlaylists = currentTab == Tab.PLAYLISTS && opened == null
        newPlaylist.visibility = if (currentTab == Tab.PLAYLISTS) View.VISIBLE else View.GONE
        newPlaylist.text = if (opened == null) "+ Criar lista" else "‹ Voltar"
        if (showingPlaylists) {
            sectionTitle.text = "Suas playlists"
            val rows = libraryStore.playlists.map { (name, uris) -> name to uris.size }
                .filter { (name, _) -> name.lowercase(Locale.getDefault()).contains(filter) }
            recycler.adapter = playlistAdapter
            playlistAdapter.submit(rows)
            emptyView.text = "Sem playlists por enquanto.\nToque em + Criar lista para começar."
            emptyView.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        } else {
            sectionTitle.text = when {
                opened != null -> opened
                currentTab == Tab.FAVORITES -> "Suas favoritas"
                else -> "Sua biblioteca"
            }
            val tracks = when {
                opened != null -> {
                    val byUri = library.associateBy { it.uri }
                    libraryStore.playlists[opened].orEmpty().mapNotNull { byUri[it] }
                }
                currentTab == Tab.FAVORITES -> library.filter { it.uri in libraryStore.favorites }
                else -> library
            }.filter { it.title.lowercase(Locale.getDefault()).contains(filter) ||
                       it.artist.lowercase(Locale.getDefault()).contains(filter) }
            recycler.adapter = songAdapter
            songAdapter.submit(tracks)
            emptyView.text = when {
                opened != null -> "Esta playlist está vazia.\nUse ⋮ em uma música para adicioná-la."
                currentTab == Tab.FAVORITES -> "Nenhuma favorita ainda.\nToque no coração de uma faixa."
                !libraryStore.hasMediaPermission() -> "Permissão de músicas não concedida.\nUse + para selecionar um arquivo."
                else -> "Nenhuma música encontrada.\nToque em + para importar um arquivo."
            }
            emptyView.visibility = if (tracks.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun playQueue(tracks: List<Track>, index: Int) {
        val player = controller ?: run { toast("Conectando ao player..."); return }
        if (tracks.isEmpty() || index !in tracks.indices) return
        val items = tracks.map { track ->
            MediaItem.Builder()
                .setUri(Uri.parse(track.uri))
                .setMediaId(track.uri)
                .setMediaMetadata(MediaMetadata.Builder()
                    .setTitle(track.title)
                    .setArtist(track.artist)
                    .build())
                .build()
        }
        player.setMediaItems(items, index, 0L)
        player.prepare()
        player.play()
        updatePlayerUi()
    }

    private fun updatePlayerUi() {
        if (!::playerTitle.isInitialized) return
        val player = controller
        val track = player?.currentMediaItem
        playerTitle.text = track?.mediaMetadata?.title ?: "Nada tocando"
        playerArtist.text = track?.mediaMetadata?.artist ?: "Escolha uma música"
        playPause.text = if (player?.isPlaying == true) "❚❚" else "▶"
        favoriteButton.text = if (track != null && track.mediaId in libraryStore.favorites) "♥" else "♡"
        favoriteButton.alpha = if (track == null) 0.45f else 1f
        updatePlayerProgress()
    }

    private fun updatePlayerProgress() {
        if (!::seekBar.isInitialized) return
        val player = controller
        val duration = player?.duration ?: C.TIME_UNSET
        val hasDuration = duration > 0 && duration != C.TIME_UNSET
        totalTime.text = if (hasDuration) formatTime(duration) else "0:00"
        seekBar.isEnabled = hasDuration
        seekBar.max = if (hasDuration) (duration / 1000L).coerceIn(1L, Int.MAX_VALUE.toLong()).toInt() else 1
        if (!userScrubbing) {
            val position = (player?.currentPosition ?: 0L).coerceAtLeast(0L)
            seekBar.progress = if (hasDuration) (position / 1000L).coerceIn(0, seekBar.max.toLong()).toInt() else 0
            currentTime.text = formatTime(position)
        }
    }

    private fun addAudioOptions() {
        val options = arrayOf("Importar arquivo MP3 / áudio", "Adicionar URL HTTPS de áudio", "Atualizar músicas do celular")
        AlertDialog.Builder(this).setTitle("Adicionar música")
            .setItems(options) { _, index -> when (index) {
                0 -> filePicker.launch(arrayOf("audio/*"))
                1 -> addAudioUrl()
                2 -> { scanLibrary(); toast("Atualizando biblioteca...") }
            } }.show()
    }

    private fun addAudioUrl() {
        val input = EditText(this).apply {
            hint = "https://exemplo.com/musica.mp3"
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
            setPadding(38, 20, 38, 20)
        }
        AlertDialog.Builder(this).setTitle("Áudio por link")
            .setMessage("Use um arquivo ou stream HTTPS que você tem autorização para reproduzir (MP3, AAC ou HLS). Links comuns de vídeos do YouTube não são áudio direto.")
            .setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Adicionar") { _, _ ->
                val raw = input.text.toString().trim()
                val uri = Uri.parse(raw)
                val valid = uri.scheme.equals("https", ignoreCase = true) && !uri.host.isNullOrBlank() &&
                    uri.host?.lowercase(Locale.US)?.let { host ->
                        host != "youtube.com" && !host.endsWith(".youtube.com") && host != "youtu.be"
                    } == true
                if (!valid) { toast("Informe um endereço HTTPS direto de áudio válido."); return@setPositiveButton }
                val title = uri.lastPathSegment?.substringBefore('?')?.substringBeforeLast('.')?.take(80)
                    .orEmpty().ifBlank { "Áudio online" }
                libraryStore.addImported(Track(raw, title, "Stream HTTPS", "stream"))
                scanLibrary()
            }.show()
    }

    private fun showTrackOptions(anchor: View, track: Track) {
        PopupMenu(this, anchor).apply {
            val add = menu.add("Adicionar a uma playlist")
            val removeFromList = if (openedPlaylist != null) menu.add("Remover desta playlist") else null
            val removeImported = if (track.source != "device") menu.add("Remover da biblioteca") else null
            setOnMenuItemClickListener { item ->
                when (item) {
                    add -> choosePlaylist(track)
                    removeFromList -> { openedPlaylist?.let { libraryStore.removeFromPlaylist(it, track.uri) }; refreshContent() }
                    removeImported -> {
                        libraryStore.removeImported(track.uri)
                        scanLibrary()
                    }
                }
                true
            }
        }.show()
    }

    private fun choosePlaylist(track: Track) {
        if (libraryStore.playlists.isEmpty()) {
            toast("Crie uma playlist primeiro")
            showCreatePlaylist()
            return
        }
        val names = libraryStore.playlists.keys.toTypedArray()
        AlertDialog.Builder(this).setTitle("Adicionar '${track.title}' em:")
            .setItems(names) { _, index ->
                libraryStore.addToPlaylist(names[index], track.uri)
                toast("Adicionada a ${names[index]}")
                refreshContent()
            }.show()
    }

    private fun showCreatePlaylist() {
        val input = EditText(this).apply {
            hint = "Ex.: Favoritas para estudar"
            setSingleLine(true)
            setPadding(40, 22, 40, 22)
        }
        AlertDialog.Builder(this).setTitle("Nova playlist")
            .setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Criar") { _, _ ->
                if (!libraryStore.createPlaylist(input.text.toString())) toast("Digite um nome novo e válido")
                else { currentTab = Tab.PLAYLISTS; openedPlaylist = null; refreshContent() }
            }.show()
    }

    private fun formatTime(milliseconds: Long): String {
        val seconds = (milliseconds.coerceAtLeast(0L) / 1000L)
        return if (seconds >= 3600) String.format(Locale.getDefault(), "%d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60)
        else String.format(Locale.getDefault(), "%d:%02d", seconds / 60, seconds % 60)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onStart() {
        super.onStart()
        progressHandler.post(progressTask)
    }

    override fun onStop() {
        progressHandler.removeCallbacks(progressTask)
        super.onStop()
    }

    override fun onDestroy() {
        progressHandler.removeCallbacks(progressTask)
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
