package com.sonsplayer.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import kotlin.concurrent.thread

/**
 * Consulta títulos/vídeos de uma playlist pública via YouTube Data API v3.
 * Os vídeos são abertos no YouTube oficial. NÃO baixa nem extrai áudio.
 * A chave é digitada em tempo de execução e NÃO é salva no aparelho.
 */
class YouTubePlaylistActivity : AppCompatActivity() {
    private lateinit var input: EditText
    private lateinit var keyInput: EditText
    private lateinit var status: TextView
    private lateinit var adapter: VideoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_youtube)
        input = findViewById(R.id.ytPlaylistInput)
        keyInput = findViewById(R.id.ytApiKeyInput)
        status = findViewById(R.id.ytStatus)
        findViewById<View>(R.id.ytBack).setOnClickListener { finish() }
        adapter = VideoAdapter { videoId -> openYoutube("https://www.youtube.com/watch?v=$videoId") }
        findViewById<RecyclerView>(R.id.ytResults).apply {
            layoutManager = LinearLayoutManager(this@YouTubePlaylistActivity)
            adapter = this@YouTubePlaylistActivity.adapter
        }
        val preferences = getSharedPreferences("sons_yt", MODE_PRIVATE)
        input.setText(preferences.getString("last_playlist", ""))

        findViewById<View>(R.id.ytOpen).setOnClickListener {
            val playlistId = parsePlaylistId(input.text.toString())
            if (playlistId == null) status.text = "Informe um ID ou URL de playlist válida."
            else openYoutube("https://www.youtube.com/playlist?list=$playlistId")
        }
        findViewById<View>(R.id.ytLoad).setOnClickListener {
            val playlistId = parsePlaylistId(input.text.toString())
            val apiKey = keyInput.text.toString().trim()
            when {
                playlistId == null -> status.text = "Insira a URL ou ID de uma playlist válida."
                apiKey.isBlank() -> status.text = "Para consultar os títulos, insira uma chave da YouTube Data API v3. Sem chave, use 'Abrir playlist no YouTube'."
                else -> {
                    preferences.edit().putString("last_playlist", playlistId).apply()
                    fetchPlaylist(playlistId, apiKey)
                }
            }
        }
    }

    private fun parsePlaylistId(raw: String): String? {
        val trimmed = raw.trim()
        val id = when {
            trimmed.startsWith("https://", true) || trimmed.startsWith("http://", true) -> {
                val uri = Uri.parse(trimmed)
                val host = uri.host?.lowercase() ?: return null
                if (host != "youtube.com" && host != "www.youtube.com" && host != "m.youtube.com" && host != "music.youtube.com") return null
                uri.getQueryParameter("list")
            }
            else -> trimmed
        }
        return id?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{12,80}")) }
    }

    private fun fetchPlaylist(id: String, apiKey: String) {
        status.text = "Carregando playlist pública..."
        adapter.submit(emptyList())
        thread(name = "sons-youtube-api") {
            try {
                val results = mutableListOf<Video>()
                var nextToken: String? = null
                // Máximo 200 resultados por consulta para não consumir quota sem limite.
                for (page in 0 until 4) {
                    val params = linkedMapOf(
                        "part" to "snippet,contentDetails",
                        "playlistId" to id,
                        "maxResults" to "50",
                        "key" to apiKey
                    )
                    if (!nextToken.isNullOrBlank()) params["pageToken"] = nextToken!!
                    val query = params.entries.joinToString("&") { (k, v) ->
                        "${encode(k)}=${encode(v)}"
                    }
                    val connection = URL("https://www.googleapis.com/youtube/v3/playlistItems?$query")
                        .openConnection() as HttpURLConnection
                    val json = try {
                        connection.connectTimeout = 10000
                        connection.readTimeout = 12000
                        connection.requestMethod = "GET"
                        val code = connection.responseCode
                        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                        val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                        if (code !in 200..299) {
                            val detail = try { JSONObject(response).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                            throw IllegalStateException(detail ?: "Erro HTTP $code")
                        }
                        JSONObject(response)
                    } finally {
                        connection.disconnect()
                    }
                    val items = json.optJSONArray("items")
                    if (items != null) for (i in 0 until items.length()) {
                        val item = items.optJSONObject(i) ?: continue
                        val title = item.optJSONObject("snippet")?.optString("title") ?: continue
                        val vid = item.optJSONObject("contentDetails")?.optString("videoId") ?: continue
                        if (vid.matches(Regex("[A-Za-z0-9_-]{11}")) && title != "Private video" && title != "Deleted video") {
                            val channel = item.optJSONObject("snippet")?.optString("videoOwnerChannelTitle") ?: "YouTube"
                            results.add(Video(title, channel, vid))
                        }
                    }
                    nextToken = json.optString("nextPageToken").takeIf { it.isNotBlank() }
                    if (nextToken == null) break
                }
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        adapter.submit(results)
                        status.text = if (results.isEmpty()) "Nenhum vídeo público encontrado." else "${results.size} vídeos • Toque para abrir no YouTube"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) status.text = "Não foi possível consultar a playlist: ${e.message ?: "verifique a chave e a conexão"}"
                }
            }
        }
    }

    private fun encode(s: String): String = URLEncoder.encode(s, StandardCharsets.UTF_8.name())

    private fun openYoutube(url: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private data class Video(val title: String, val channel: String, val id: String)
    private class VideoAdapter(private val onOpen: (String) -> Unit) : RecyclerView.Adapter<VideoAdapter.Holder>() {
        private var items: List<Video> = emptyList()
        fun submit(videos: List<Video>) { items = videos; notifyDataSetChanged() }
        class Holder(view: View) : RecyclerView.ViewHolder(view) {
            val title: TextView = view.findViewById(R.id.trackTitle)
            val artist: TextView = view.findViewById(R.id.trackArtist)
            val favorite: TextView = view.findViewById(R.id.trackFavorite)
            val menu: TextView = view.findViewById(R.id.trackMenu)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder = Holder(
            LayoutInflater.from(parent.context).inflate(R.layout.row_song, parent, false)
        )
        override fun getItemCount(): Int = items.size
        override fun onBindViewHolder(holder: Holder, position: Int) {
            val video = items[position]
            holder.title.text = video.title
            holder.artist.text = video.channel
            holder.favorite.visibility = View.GONE
            holder.menu.text = "↗"
            holder.itemView.setOnClickListener { onOpen(video.id) }
            holder.menu.setOnClickListener { onOpen(video.id) }
        }
    }
}
