package com.sonsplayer.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PlaylistAdapter(
    private val onOpen: (String) -> Unit,
    private val onOptions: (View, String) -> Unit
) : RecyclerView.Adapter<PlaylistAdapter.Holder>() {
    private var items: List<Pair<String, Int>> = emptyList()
    fun submit(data: List<Pair<String, Int>>) { items = data; notifyDataSetChanged() }
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.playlistName)
        val count: TextView = view.findViewById(R.id.playlistCount)
        val options: TextView = view.findViewById(R.id.playlistOptions)
    }
    override fun onCreateViewHolder(parent: ViewGroup, type: Int): Holder = Holder(
        LayoutInflater.from(parent.context).inflate(R.layout.row_playlist, parent, false)
    )
    override fun getItemCount(): Int = items.size
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val (name, count) = items[position]
        holder.name.text = name
        holder.count.text = "$count ${if (count == 1) "faixa" else "faixas"}"
        holder.itemView.setOnClickListener { onOpen(name) }
        holder.options.setOnClickListener { onOptions(holder.options, name) }
    }
}
