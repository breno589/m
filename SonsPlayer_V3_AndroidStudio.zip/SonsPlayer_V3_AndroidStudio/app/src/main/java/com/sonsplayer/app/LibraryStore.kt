package com.sonsplayer.app

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Biblioteca local + itens importados via SAF. Não acessa o YouTube para extrair áudio. */
class LibraryStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("sons_library_v3", Context.MODE_PRIVATE)

    val favorites: MutableSet<String> = prefs.getStringSet("favorites", emptySet()).orEmpty().toMutableSet()
    val playlists: LinkedHashMap<String, MutableList<String>> = linkedMapOf()
    val imported: MutableList<Track> = mutableListOf()

    init {
        try {
            val obj = JSONObject(prefs.getString("playlists", "{}") ?: "{}")
            val keys = obj.keys()
            while (keys.hasNext()) {
                val name = keys.next()
                val tracks = obj.optJSONArray(name) ?: JSONArray()
                playlists[name] = MutableList(tracks.length()) { i -> tracks.optString(i) }
            }
        } catch (_: Exception) { /* Biblioteca antiga/corrompida: inicia vazia. */ }
        try {
            val saved = JSONArray(prefs.getString("imported", "[]") ?: "[]")
            for (i in 0 until saved.length()) imported.add(Track.fromJson(saved.getJSONObject(i)))
        } catch (_: Exception) { }
    }

    fun permissionName(): String = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasMediaPermission(): Boolean = ContextCompat.checkSelfPermission(context, permissionName()) == PackageManager.PERMISSION_GRANTED

    fun loadAll(): List<Track> {
        val tracks = mutableListOf<Track>()
        if (hasMediaPermission()) {
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST
            )
            try {
                context.contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    projection, null, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
                )?.use { cursor ->
                    val idIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idIndex)
                        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                        tracks.add(Track(uri.toString(), cursor.getString(titleIndex) ?: "Sem título",
                            cursor.getString(artistIndex)?.takeUnless { it == "<unknown>" } ?: "Artista desconhecido"))
                    }
                }
            } catch (_: SecurityException) { /* permissão revogada durante a leitura */ }
            catch (_: Exception) { /* arquivos do provedor indisponíveis */ }
        }
        val known = tracks.mapTo(hashSetOf()) { it.uri }
        imported.forEach { if (known.add(it.uri)) tracks.add(it) }
        return tracks.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
    }

    fun toggleFavorite(uri: String): Boolean {
        val nowFavorite = if (uri in favorites) { favorites.remove(uri); false } else { favorites.add(uri); true }
        // SharedPreferences exige nova instância do Set.
        prefs.edit().putStringSet("favorites", favorites.toSet()).apply()
        return nowFavorite
    }

    fun createPlaylist(name: String): Boolean {
        val clean = name.trim()
        if (clean.isBlank() || playlists.keys.any { it.equals(clean, ignoreCase = true) }) return false
        playlists[clean] = mutableListOf()
        persistPlaylists()
        return true
    }

    fun deletePlaylist(name: String) { playlists.remove(name); persistPlaylists() }

    fun addToPlaylist(name: String, uri: String) {
        val items = playlists[name] ?: return
        if (uri !in items) { items.add(uri); persistPlaylists() }
    }

    fun removeFromPlaylist(name: String, uri: String) {
        playlists[name]?.remove(uri)
        persistPlaylists()
    }

    fun addImported(track: Track) {
        imported.removeAll { it.uri == track.uri }
        imported.add(track)
        persistImported()
    }

    fun removeImported(uri: String) {
        imported.removeAll { it.uri == uri }
        favorites.remove(uri)
        prefs.edit().putStringSet("favorites", favorites.toSet()).apply()
        playlists.values.forEach { it.remove(uri) }
        persistImported()
        persistPlaylists()
    }

    private fun persistImported() {
        val arr = JSONArray()
        imported.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("imported", arr.toString()).apply()
    }

    private fun persistPlaylists() {
        val obj = JSONObject()
        playlists.forEach { (name, uris) ->
            val arr = JSONArray()
            uris.forEach { arr.put(it) }
            obj.put(name, arr)
        }
        prefs.edit().putString("playlists", obj.toString()).apply()
    }
}
