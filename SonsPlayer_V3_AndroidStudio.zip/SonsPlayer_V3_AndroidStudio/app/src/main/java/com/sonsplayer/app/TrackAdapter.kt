package com.sonsplayer.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TrackAdapter(
    private val isFavorite: (String) -> Boolean,
    private val onPlay: (Track, Int) -> Unit,
    private val onFavorite: (Track) -> Unit,
    private val onMenu: (View, Track) -> Unit
) : RecyclerView.Adapter<TrackAdapter.Holder>() {
    private var tracks: List<Track> = emptyList()
    fun submit(newTracks: List<Track>) {
        tracks = newTracks
        notifyDataSetChanged()
    }
    fun current(): List<Track> = tracks

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.trackTitle)
        val artist: TextView = view.findViewById(R.id.trackArtist)
        val favorite: TextView = view.findViewById(R.id.trackFavorite)
        val menu: TextView = view.findViewById(R.id.trackMenu)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder = Holder(
        LayoutInflater.from(parent.context).inflate(R.layout.row_song, parent, false)
    )
    override fun getItemCount() = tracks.size
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val track = tracks[position]
        holder.title.text = track.title
        holder.artist.text = track.artist
        holder.favorite.text = if (isFavorite(track.uri)) "♥" else "♡"
        holder.itemView.setOnClickListener { onPlay(track, holder.bindingAdapterPosition) }
        holder.itemView.setOnLongClickListener { onMenu(holder.menu, track); true }
        holder.favorite.setOnClickListener { onFavorite(track) }
        holder.menu.setOnClickListener { onMenu(holder.menu, track) }
    }
}
