package com.sonsplayer.app

import org.json.JSONObject

data class Track(
    val uri: String,
    val title: String,
    val artist: String,
    val source: String = "device"
) {
    fun toJson(): JSONObject = JSONObject()
        .put("uri", uri)
        .put("title", title)
        .put("artist", artist)
        .put("source", source)

    companion object {
        fun fromJson(json: JSONObject): Track = Track(
            json.getString("uri"),
            json.optString("title", "Sem título"),
            json.optString("artist", "Artista desconhecido"),
            json.optString("source", "imported")
        )
    }
}
